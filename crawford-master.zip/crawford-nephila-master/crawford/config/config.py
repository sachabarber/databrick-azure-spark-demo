"""
Application Configuration file.
Values are loaded with ConfigParser.
DO NOT hard-code new configuration here, add to config.json and read in instead
"""
import json

with open('config/config.json') as json_data_file:
    _config = json.load(json_data_file)


class Config(object):
    def __init__(self, config):
        """RiskStore DW connection"""
        self.azure_server_name = config['ConnectionStrings']['azure_server_name']
        self.azure_db_name = config['ConnectionStrings']['azure_db_name']
        self.azure_username = config['ConnectionStrings']['azure_username']
        self.azure_password = config['ConnectionStrings']['azure_password']

        """RiskStore Bridge connection"""
        self.azure_rsbridge_server_name = config['ConnectionStrings']['azure_rsbridge_server_name']
        self.azure_rsbridge_db_name = config['ConnectionStrings']['azure_rsbridge_db_name']
        self.azure_rsbridge_username = config['ConnectionStrings']['azure_rsbridge_username']
        self.azure_rsbridge_password = config['ConnectionStrings']['azure_rsbridge_password']

        """RiskStore REST endpoint"""
        self.riskstore_rest_endpoint = config['AppSettings']['riskstore_rest_endpoint']

        """Globals"""
        self.is_debug_mode = bool(config['AppSettings']['is_debug_mode'])
        self.default_source_deal_system = config['AppSettings']['source_deal_system']
        self.default_simulation_count = int(config['AppSettings']['simulation_count'])

        """Logging"""
        self.log_minimum_level = config['AppSettings']['log_minimum_level']
        self.log_base_filename = config['AppSettings']['log_base_filename']
        self.log_max_size_bytes = float(config['AppSettings']['log_max_size_bytes'])
        self.log_backup_count = int(config['AppSettings']['log_backup_count'])
        self.log_format = config['AppSettings']['log_format']

        """Cache"""
        self.cache_size_limit_bytes = config['AppSettings']['cache_size_limit_bytes']
        self.cache_dir = config['AppSettings']['cache_dir']

        """Job Queue"""
        self.job_worker_allocation = config['AppSettings']['job_worker_allocation']

config = Config(_config)
config