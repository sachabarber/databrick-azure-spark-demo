from setuptools import setup, find_packages
from setuptools.command.develop import develop
from setuptools.command.install import install
from subprocess import check_call

nephila_crawford_version = '0.0.1'
nephila_ratchet_version = '2.5.432'


class InstallCommand(install):
    """Custom installation for install mode."""


def run(self):
    check_call("pip install ratchet/nephila_ratchet-{0}.zip".format(nephila_ratchet_version).split())
    install.do_egg_install(self)


setup(
    name='crawford',
    version='{0}'.format(nephila_crawford_version),
    description='Nephila Calc Lite Tool',
    author='jburns',
    author_email='jburns@nephilaadvisors.com',
    url='https://stash.nephila.com/projects/SPIK/repos/crawford',
    zip_safe=False,
    scripts=[],
    packages=find_packages(exclude=('tests', 'docs')),
    include_package_data=True, #See MANIFEST.in for included data
    cmdclass={
        'install': InstallCommand,
    },
    install_requires=[
        'retrying==1.3.3',
        'Flask-Testing==0.6.2',
        'Flask==0.12.2',
        'pytest==3.2.3',
        'mock==1.3.0',
        'pandas==0.21.0',
        'findspark',
        'pyspark'
    ]
)
