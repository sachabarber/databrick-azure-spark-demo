from flask import Flask
from flask import request
from engine import dummy_calculator
app = Flask(__name__)


@app.route('/')
def hello():
    return "Hello World!"


@app.route('/add')
def add():
    a = int(request.args.get("a"))
    b = int(request.args.get("b"))
    return str(dummy_calculator.DummyCalculator.calculate(a, b))


if __name__ == '__main__':
    app.run(host='localhost', port=8085)