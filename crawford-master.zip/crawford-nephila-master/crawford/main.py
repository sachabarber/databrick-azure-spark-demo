import logging
from config.config import config
from engine import dummy_calculator
from engine import simple_calculator
from engine import spark_calculator
from pyspark.sql.functions import lit
import timeit
import findspark
from pyspark import SparkContext
from pyspark import SparkConf
import pyspark.sql

use_inurings = False
apply_factors = False

limit = 50 * 10 ** 9
excess = 5 * 10 ** 9


def run_simple_calc(df):
    simple_calc = simple_calculator.SimpleCalculator(df, limit, excess)
    df, inurings = simple_calc.load_loss_data()
    results_df = simple_calc.calculate(df, inurings)
    print(results_df['TotalLoss'].sum())  # 3.31726223599e+12
    print('Simple calc sum layer attrition: {}'.format(results_df['LayerAttrition'].sum()))
    #print(timeit.timeit(lambda: simple_calc.calculate(df, inurings), number=10))


def run_spark_calc(df):
    df = df.withColumn('LayerAttrition', lit(0.0))
    df = df.withColumn('ReinstatementAttrition', lit(0.0))
    spark_calc = spark_calculator.SparkCalculator(limit, excess)

    if apply_factors:
        df = spark_calc.apply_factors(df)
    else:
        df = df.withColumn('FactorLoss', df.Loss)

    if use_inurings:
        inurings = spark_calc.load_inurings(df)
        df = spark_calc.apply_inurings(inurings, df)

    results_df = df.toPandas().groupby('Simulation').apply(spark_calc.calculate_simulation)
    print('spark calc sum layer attrition: {}'.format(results_df['LayerAttrition'].sum()))


if __name__ == '__main__':
    findspark.init()
    sc = SparkContext.getOrCreate()
    sqlContext = pyspark.sql.SQLContext(sc)

    log_level = getattr(logging, config.log_minimum_level.upper(), None)
    logging.basicConfig(level=logging.ERROR)
    logger = logging.getLogger(__name__)

    ww_parquet_path = '../data/extracts/v18/worldwide/105670/biggest-year/parquet/'
    spark_df = sqlContext.read.load(ww_parquet_path)
    # print(spark_df.describe().show())
    run_spark_calc(spark_df)
    run_simple_calc(spark_df.toPandas())
