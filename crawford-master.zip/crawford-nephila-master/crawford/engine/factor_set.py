
# Similar to how it's done in Rubick.

class FlatFactor:
    def __init__(self):
        pass

    def get_factor(self):
        return 1.1


class GeographicalFactor:
    def __init__(self):
        self.values = [1.03 for _ in range(1000)]

    def get_factor(self, geo_id):
        if geo_id >= len(self.values):
            return 1.0
        else:
            return self.values[geo_id]