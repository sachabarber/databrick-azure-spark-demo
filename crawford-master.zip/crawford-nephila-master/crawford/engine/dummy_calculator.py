class DummyCalculator:

    @staticmethod
    def calculate(a, b):
        return a + b
