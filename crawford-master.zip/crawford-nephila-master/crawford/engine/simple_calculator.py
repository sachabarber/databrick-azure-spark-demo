import pandas as pd
from engine import factor_set as fs


class SimpleCalculator:
    def __init__(self, loss_df, limit, excess):
        self.loss_df = loss_df
        self.limit = limit
        self.excess = excess

    def load_loss_data(self):
        loss_df = self.loss_df
        loss_df['LayerAttrition'] = 0.0
        loss_df['ReinstatementAttrition'] = 0.0
        loss_df['FactorLoss'] = loss_df['Loss']

        inurings = []

        for i in range(1):
            inuring = loss_df.copy(deep=True)
            inuring['Loss'] *= 0.0
            inurings.append(inuring)

        return loss_df, inurings

    def calculate(self, loss_df, inurings):
        self.apply_factors(loss_df)
        df_sims = loss_df#self.apply_inuring(inurings, loss_df)

        sim_events_results = []

        for sim_year, sim_events_df in df_sims.groupby('Simulation'):
            #inuring_sim_dfs = [_.get_group(sim_year) for _ in inurings]
            sim_events_df = self.calculate_simulation(sim_events_df)#, inuring_sim_dfs)
            # print(sim_year)
        sim_events_results.append(sim_events_df)
        return pd.concat(sim_events_results)

    def calculate_simulation(self, sim_events_df):#, inuring_sim_dfs):

        # Filter out areas perils lobs

        self.apply_factors(sim_events_df)

        # Apply inurings

        #sim_events_df = self.apply_inuring(inuring_sim_dfs, sim_events_df)

        # Sort by Day
        sim_events_df = sim_events_df.sort_values('EventDay')

        # Group losses to event total && apply terms

        event_total_df = sim_events_df.groupby(['EventId'])['FactorLoss'].agg('sum').reset_index().set_index('EventId')
        event_total_df = event_total_df.rename(columns={'FactorLoss': 'TotalLoss'})
        event_total_df['PostTermsLoss'] = 0.0

        for event in event_total_df.itertuples():
            post_terms_loss = min(self.limit, max(0, event.TotalLoss - self.excess))
            event_total_df.at[event.Index, 'PostTermsLoss'] = post_terms_loss

        # Backallocate values
        sim_events_df = pd.merge(sim_events_df, event_total_df, how='inner', left_on='EventId', right_index=True)
        sim_events_df['LayerAttrition'] = sim_events_df['FactorLoss'] / sim_events_df['TotalLoss'] * sim_events_df['PostTermsLoss'] / self.limit

        # print(sim_events_df.head(5))
        # print(sim_events_df.shape)
        return sim_events_df

    def apply_inuring(self, inuring_sim_dfs, sim_df):
        for inuring_sim_df in inuring_sim_dfs:
            # print(inuring_sim_df.shape)
            # print(sim_events_df.shape)

            sim_df = pd.merge(left=sim_df, how='left',
                                     left_on=['Simulation', 'EventId', 'EventDay', 'PerilId', 'LobId', 'GeoId'],
                                     right_on=['Simulation', 'EventId', 'EventDay', 'PerilId', 'LobId', 'GeoId'],
                                     right=inuring_sim_df[['Simulation', 'EventId', 'EventDay', 'PerilId', 'LobId',
                                                           'GeoId', 'Loss']])

            sim_df['FactorLoss'] -= sim_df['Loss_y']
            sim_df = sim_df.drop(['Loss_y'], axis=1)
            sim_df = sim_df.rename(columns={'Loss_x': 'Loss'})

        return sim_df

    def apply_factors(self, sim_df):
        # Apply factors
        ff = fs.FlatFactor()
        af = fs.GeographicalFactor()
        for event_row in sim_df.itertuples():
            factor = ff.get_factor() * af.get_factor(event_row.GeoId)
            sim_df.at[event_row.Index, 'FactorLoss'] = event_row.Loss * factor
