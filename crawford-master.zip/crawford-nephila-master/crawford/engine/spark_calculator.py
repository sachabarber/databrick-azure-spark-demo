import pandas as pd
from engine import factor_set as fs
from pyspark.sql.functions import lit
from pyspark.sql.types import *
from pyspark.sql.functions import col, count, rand, collect_list, explode, struct, count
import pyspark.sql.functions as F


class SparkCalculator:
    def __init__(self, limit, excess):
        self.ff = fs.FlatFactor()
        self.af = fs.GeographicalFactor()
        self.limit = limit
        self.excess = excess

    @staticmethod
    def load_inurings(loss_df):
        inurings = []

        for i in range(1):
            inuring = loss_df
            inuring = inuring.withColumn('InuringLoss', inuring['Loss'] * 0.1)
            inuring = inuring.drop('Loss')
            inuring = inuring.withColumnRenamed('InuringLoss', 'Loss')
            inurings.append(inuring)
        return inurings

    @staticmethod
    def apply_inurings(inurings, df):

        for inuring_df in inurings:
            condition = [df.Simulation == inuring_df.Simulation,
                         df.EventId == inuring_df.EventId,
                         df.EventDay == inuring_df.EventDay,
                         df.PerilId == inuring_df.PerilId,
                         df.LobId == inuring_df.LobId,
                         df.GeoId == inuring_df.GeoId]
            df = df.withColumnRenamed('Loss', 'Loss_x')
            inuring_df = inuring_df.withColumnRenamed('Loss', 'Loss_y')
            df = df.join(inuring_df,
                         condition,
                         'left_outer').select(df.Simulation, df.EventId, df.EventDay, df.PerilId, df.LobId, df.GeoId,
                                              df.Loss_x, inuring_df.Loss_y, df.FactorLoss)
            df = df.withColumn('FactorLoss2', df.FactorLoss - df.Loss_y)
            df = df.drop('FactorLoss')
            df = df.withColumnRenamed('FactorLoss2', 'FactorLoss')
            df = df.drop('Loss_y')
            df = df.withColumnRenamed('Loss_x', 'Loss')
        return df

    def calculate_simulation(self, sim_events_df):

        # Sort by Day
        sim_events_df = sim_events_df.sort_values('EventDay')

        # Group losses to event total && apply terms
        event_total_df = sim_events_df.groupby(['EventId'])['FactorLoss'].agg('sum').reset_index().set_index('EventId')
        event_total_df = event_total_df.rename(columns={'FactorLoss': 'TotalLoss'})
        event_total_df['PostTermsLoss'] = 0.0

        for event in event_total_df.itertuples():
            post_terms_loss = min(self.limit, max(0, event.TotalLoss - self.excess))
            event_total_df.at[event.Index, 'PostTermsLoss'] = post_terms_loss

        # Backallocate values
        sim_events_df = pd.merge(sim_events_df, event_total_df, how='inner', left_on='EventId', right_index=True)
        sim_events_df['LayerAttrition'] = sim_events_df['FactorLoss'] / sim_events_df['TotalLoss'] * sim_events_df[
            'PostTermsLoss'] / self.limit

        return sim_events_df
