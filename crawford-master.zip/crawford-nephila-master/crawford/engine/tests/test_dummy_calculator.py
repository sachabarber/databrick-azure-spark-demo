import unittest
from engine import dummy_calculator


class DummyCalculatorTestCase(unittest.TestCase):

    def test_calculate(self):
        a = 3
        b = 5
        actual = dummy_calculator.DummyCalculator.calculate(a, b)
        self.assertEqual(actual, 8)


if __name__ == '__main__':
    unittest.main()
