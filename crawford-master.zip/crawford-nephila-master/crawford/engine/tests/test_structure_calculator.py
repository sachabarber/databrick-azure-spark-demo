import unittest
import numpy as np
import pandas as pd
import sys
from engine import structure_calculator


class StructureCalculatorTestCase(unittest.TestCase):

    def test_calculate(self):
        limit = 15
        excess = 3
        reinstatement_percentage = 1
        num_reinstatements = 1
        nth_event = 1

        calculator = structure_calculator.StructureCalculator(limit, excess, nth_event,
                                                                        reinstatement_percentage, num_reinstatements)

        data = np.array([['EventId', 'Simulation', 'EventDay', 'GeoId', 'LobId', 'PerilId', 'Loss'],
                         [1, 1, 1, 0, 0, 0, 5],
                         [2, 1, 2, 0, 0, 0, 5],
                         [3, 1, 152, 0, 0, 0, 5],
                         [4, 1, 153, 0, 0, 0, 5],
                         [5, 1, 244, 0, 0, 0, 10],
                         [6, 1, 245, 0, 0, 0, 10]])

        dtype = {'EventId': 'int64', 'Simulation':'int64', 'EventDay':'int64', 'GeoId':'int64',
                 'LobId':'int64', 'PerilId':'int64', 'Loss':'float64'}

        input_events = pd.DataFrame(data=data[1:, 0:],
                           index=data[1:, 0],
                           columns=data[0, 0:])

        input_events = input_events.astype(dtype=dtype)

        actual = calculator.calculate_sim(input_events)

        print (actual)
        #self.assertEqual(actual, 8)


if __name__ == '__main__':
    unittest.main()
