import unittest
import numpy as np
import pandas as pd
import sys
from engine import calc_tree


class CalcTreeCase(unittest.TestCase):

    def test_calculate(self):
        limit = 15
        excess = 3

        ct = calc_tree.CalcTree(limit, excess)

        ct.calc()

if __name__ == '__main__':
    unittest.main()
