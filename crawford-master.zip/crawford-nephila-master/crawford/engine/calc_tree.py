import pandas as pd
from engine import factor_set as fs
from pyspark.sql.functions import lit
from pyspark.sql.types import *
from pyspark.sql.functions import col, count, rand, collect_list, explode, struct, count
import pyspark.sql.functions as F
import networkx as nx

class CalcTree:
    def __init__(self, limit, excess):
        self.limit = limit
        self.excess = excess


    def add(self, input, value):
        return input + value

    def subtract(self, input, value):
        return input - value

    def multiply(self, input, value):
        return input * value

    def calc(self):
        DG = nx.DiGraph()
        DG.add_weighted_edges_from([(1, 2, 0.5), (1, 3, 0.75), (2, 4, 0.75), (4, 5, 0.75)])
        DG.out_degree(1, weight='weight')

        DG.degree(1, weight='weight')

        successors = list(DG.successors(1))

        neighbours = list(DG.neighbors(2))

        sorted = (list(nx.lexicographical_topological_sort(DG)))
        chain = DG.in_degree()
        print(neighbours)