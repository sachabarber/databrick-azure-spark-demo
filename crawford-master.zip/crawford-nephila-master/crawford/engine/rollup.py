import pandas as pd
from pprint import pprint
from pyspark import  SparkContext
from pyspark import SparkConf
from pyspark.sql import DataFrame
from IPython.display import display, HTML
import matplotlib.pyplot as plt

class Rollup:
    def __init__(self, limit, excess):
        self.limit = limit
        self.excess = excess


    def calculate_deal_expected_loss_by_metarisk(self, deals, metarisks, losses):
        metarisks.filter(metarisks.MetaRiskId == 51).join(losses,
                         losses.PerilId == metarisks.PerilId,
                         losses.GeoId == metarisks.GeoId,
                         losses.LobId == metarisks.LobId).join(deals,
                            deals.EventSetId == losses.EventSetId).groupBy(deals.EventSetId,
                                       metarisks.MetaRiskId,
                                       losses.ELAgg, losses.EventSetId).agg({losses.LayerAttrition: 'sum',
                                                                             })


        people.filter(people.age > 30).join(department, people.deptId == department.id) \
            .groupBy(department.name, "gender").agg({"salary": "avg", "age": "max"})


deals_df = spark.read.csv("/mnt/%s/static/testing/deals.csv" % MOUNT_NAME, header=True)
metarisks_df = spark.read.csv("/mnt/%s/static/testing/metarisks.csv" % MOUNT_NAME, header = True)
losses_df = spark.read.parquet("/mnt/%s/calculator/*/parquet/*.parquet" % MOUNT_NAME)

metarisks_df.createOrReplaceTempView("metarisks")
losses_df.createOrReplaceTempView("losses")
deals_df.createOrReplaceTempView("deals")

%sql
SELECT DealReference, MetaRiskId, (SUM(LayerAttrition) / 10000) as CalculatedAggEL, ELAgg as ExpectedAggEL,
ABS((SUM(LayerAttrition) / 10000) - ELAgg) as Delta, ELTID
FROM losses
INNER JOIN deals ON deals.ELTID = losses.EventSetId
INNER JOIN metarisks ON metarisks.PerilId = losses.PerilId
AND metarisks.GeoId = losses.GeoId
WHERE metarisks.MetaRiskId = 51
GROUP BY DealReference, MetaRiskId, ELAgg, ELTID
ORDER BY Delta DESC
