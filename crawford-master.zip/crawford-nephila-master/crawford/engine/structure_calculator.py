import pandas as pd
import math


class StructureCalculator:
    def __init__(self, limit, excess, nth_event, reinstatement_percentage, num_reinstatements):
        #self.ff = fs.FlatFactor()
        #self.af = fs.GeographicalFactor()
        self.limit = limit
        self.excess = excess
        self.nth_event = nth_event
        self.reinstatement_percentage = reinstatement_percentage
        self.num_reinstatements = num_reinstatements


    def calculate_sim(self, sim_events_df):
        sim_events_df = sim_events_df.sort_values('EventDay')

        # Group losses to event total && apply terms
        event_total_df = sim_events_df.groupby(['EventId'])['Loss'].agg('sum').reset_index().set_index('EventId')
        event_total_df = event_total_df.rename(columns={'Loss': 'TotalLoss'})
        event_total_df['PostTermsLoss'] = 0.0
        event_total_df['ReinstatementPremium'] = 0.0

        self.layer_trigger(event_total_df)

        # Backallocate values
        #sim_events_df = pd.merge(sim_events_df, event_total_df, how='inner', left_on='EventId', right_index=True)
        #sim_events_df['LayerAttrition'] = sim_events_df['Loss'] / sim_events_df['TotalLoss'] * sim_events_df[
        #    'PostTermsLoss'] #/ self.limit

        return event_total_df

    def binary_trigger(self, event_total_df):
        num_triggered_events = 0
        available_reinstatements = self.num_reinstatements + 1
        for event in event_total_df.itertuples():
            if event.TotalLoss >= self.excess:
                num_triggered_events = num_triggered_events + 1
                if num_triggered_events >= self.nth_event & available_reinstatements > 0:
                    post_terms_loss = min(self.limit, event.TotalLoss)
                    event_total_df.at[event.Index, 'PostTermsLoss'] = post_terms_loss
                    reinstatement_premium = post_terms_loss * self.reinstatement_percentage
                    event_total_df.at[event.Index, 'ReinstatementPremium'] = reinstatement_premium
                    available_reinstatements = available_reinstatements - 1

    def layer_trigger(self, event_total_df):
        num_triggered_events = 0
        overall_layer_attrition = 0.0
        available_reinstatement_attrition = self.num_reinstatements
        available_limit = (self.limit - self.excess) * self.num_reinstatements + 1

        for event in event_total_df.itertuples():
            input_event_loss = event.TotalLoss

            if input_event_loss >= self.excess:
                num_triggered_events = num_triggered_events + 1
                if (num_triggered_events >= self.nth_event) & (available_limit > 0):
                    post_terms_loss = min(available_limit, input_event_loss - self.excess)
                    available_limit = available_limit - post_terms_loss
                    event_total_df.at[event.Index, 'PostTermsLoss'] = post_terms_loss

                    layer_attrition = post_terms_loss / (self.limit - self.excess)

                    if math.isnan(layer_attrition):
                        layer_attrition = 0.0

                    overall_layer_attrition = overall_layer_attrition + layer_attrition

                    event_total_df.at[event.Index, 'LayerAttrition'] = layer_attrition
                    event_total_df.at[event.Index, 'OverallLayerAttrition'] = overall_layer_attrition

                    reinstatement_attrition = 0.0
                    if available_reinstatement_attrition > 0:
                        reinstatement_attrition = layer_attrition * self.reinstatement_percentage
                        reinstatement_attrition = min(reinstatement_attrition, available_reinstatement_attrition)
                        available_reinstatement_attrition = available_reinstatement_attrition - reinstatement_attrition
                    event_total_df.at[event.Index, 'ReinstatementPremium'] = reinstatement_attrition

