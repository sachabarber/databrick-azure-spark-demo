USE master;  
GO  
EXEC sp_configure 'show advanced option', '1';  
RECONFIGURE; 
GO
EXEC sp_configure 'hadoop connectivity', 4; 
GO 
RECONFIGURE; 
GO



USE CRAWFORD;
CREATE MASTER KEY ENCRYPTION BY PASSWORD='Password123!';
CREATE DATABASE SCOPED CREDENTIAL jbblobstore  
WITH IDENTITY = 'optimumcadence', Secret = 'DDfHza6XN7KiSJf7ZE6d9RCVQgE2tNf4huvNZdEdBDG9nJUt0YMpbyLMd2RFWLQtE0lCxqUzdmTTkmOSY/9lFw=='


CREATE EXTERNAL DATA SOURCE calcextracts
WITH (
    TYPE = HADOOP,
    LOCATION = 'wasbs://optimumcadence@optimumcadence.blob.core.windows.net/',
    CREDENTIAL = jbblobstore
);

CREATE EXTERNAL FILE FORMAT parquet_format  
WITH (  
    FORMAT_TYPE = PARQUET,
	DATA_COMPRESSION = 
        'org.apache.hadoop.io.compress.SnappyCodec'    
   )

--https://stackoverflow.com/questions/45795117/create-external-table-in-azure-sql-data-warehouse-to-a-wild-card-based-file-or-f/45798339#45798339
 CREATE EXTERNAL TABLE [dbo].CalcExtracts (  
        [EventSetId] int NOT NULL,   
        [GeoId] int NOT NULL,   
        [PerilId] int NOT NULL,   
        [LobId] int NULL,   
        [EventId] int NOT NULL ,
		[Simulation] int NOT NULL,
		[EventDay] int NOT NULL,
		[LayerAttrition] float NOT NULL,
		[ReinstatementAttrition] float NOT NULL 
		)  
WITH (LOCATION='/optimumcadence/extracts/v18/polybase-test/',   
        DATA_SOURCE = calcextracts,  
        FILE_FORMAT = parquet_format  
);
SELECT TOP (1000) * FROM [Crawford].[dbo].[CalcExtracts]

CREATE STATISTICS CalcExtracts on CalcExtracts_Keys([EventSetId], [Simulation])  