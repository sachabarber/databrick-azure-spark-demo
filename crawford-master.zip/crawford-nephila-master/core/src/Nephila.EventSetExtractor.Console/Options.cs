﻿using System.Collections.Generic;
using CommandLine;

namespace Nephila.EventSetExtractor.Console
{
    public class Options
    {
        [Option('f', "folder", Required = true,
            HelpText = "Output folder.")]
        public string OutputFolder { get; set; }

        [Option('t', "type", Required = true,
            HelpText = "Type of extract { catrader, calculator, riskstore}")]
        public string ExtractType{ get; set; }

        [Option('i', "ids", Required = true,
            HelpText = "Eventset ids to extract")]
        public string EventSetIdCsv { get; set; }

        [Option('c', "conn", Required = false,
            HelpText = "Connection string")]
        public string ConnectionString { get; set; }
    }
}
