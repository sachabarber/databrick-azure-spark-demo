﻿using System;
using System.Drawing;
using System.Text;
using System.Threading.Tasks;
using CommandLine;
using Kurukuru;
using Microsoft.Extensions.Configuration;
using Nephila.EventSetExtractor.Services;

namespace Nephila.EventSetExtractor.Console
{
    class Program
    {
        private static string _connectionString;

        public static async Task Main(string[] args)
        {
            try
            {
                Colorful.Console.WriteAscii("EXTRACTOR", Color.HotPink);

                _connectionString =
                    "Server=10.100.60.54;Database=OPTISIMDB_Eventsets;User Id=svcCalc;Password=c@tb0nd;";
                var config = LoadConfig();

                var isParsedResult = CommandLine.Parser.Default.ParseArguments<Options>(args).Tag;

                if (isParsedResult == ParserResultType.NotParsed)
                {
                    System.Console.WriteLine("Invalid arguments");
                    return;
                }

                var options = (Parsed<Options>) CommandLine.Parser.Default.ParseArguments<Options>(args);

                var idsCsv = options.Value.EventSetIdCsv;
                var outputFolder = options.Value.OutputFolder;
                var inputConnectionString = options.Value.ConnectionString;

                if (!string.IsNullOrEmpty(inputConnectionString))
                {
                    _connectionString = inputConnectionString;
                }

                Colorful.Console.WriteLine($"Connection string: {_connectionString}");
                Colorful.Console.WriteLine($"Output folder: {outputFolder}");
                Colorful.Console.WriteLine($"t061_id csv: {idsCsv}");
                Colorful.Console.WriteLine($"Extract type: {options.Value.ExtractType}");

                await Spinner.StartAsync("Extracting...", async () =>
                {
                    switch (options.Value.ExtractType.ToUpper())
                    {
                        case "CATRADER":
                            await ExtractCatraderLossesAsync(outputFolder, idsCsv);
                            break;
                        case "CALCULATOR":
                            await ExtractCalculatorLossesAsync(outputFolder, idsCsv);
                            break;
                        default:
                            Colorful.Console.WriteLine("Invalid extractor type");
                            break;
                    }

                    System.Console.WriteLine("Finished!");
                    System.Console.WriteLine("Press any key to exit");
                    System.Console.ReadKey();
                }, Patterns.Line);

                
            }
            catch (Exception ex)
            {
                System.Console.WriteLine($"Massive error {ex.Message}");
                System.Console.ReadKey();
            }
        }

        private static async Task ExtractCatraderLossesAsync(string folderToSaveIn, string ids)
        {
            var extractor = new CatraderExtractor(_connectionString);
            var headers = await extractor.ExtractHeadersAsync(ids);
            foreach (var header in headers)
            {
                extractor.SaveEventLossesAsCsv(header, folderToSaveIn);
            }
        }

        private static async Task ExtractCalculatorLossesAsync(string folderToSaveIn, string ids)
        {
            var extractor = new CalculatorExtractor(_connectionString);
            var headers = await extractor.ExtractHeadersAsync(ids);
            foreach (var header in headers)
            {
                extractor.SaveEventLossesAsCsv(header, folderToSaveIn);
            }
        }



        private static IConfigurationRoot LoadConfig()
        {
            var environmentName = Environment.GetEnvironmentVariable("CONSOLE_ENVIRONMENT");

            var builder = new ConfigurationBuilder()
                .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true)
                .AddJsonFile($"appsettings.{environmentName}.json", optional: true)
                .AddEnvironmentVariables();
            var config = builder.Build();
            return config;
        }
    }
}
