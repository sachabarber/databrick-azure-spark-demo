﻿using System;
using System.Threading.Tasks;
using Microsoft.Azure.Documents;
using Microsoft.Azure.Documents.Client;

namespace Nephila.Dockets.WebApi.Services
{
    public interface IDocumentSvcAzure
    {
        Task<T> GetAsync<T>(Uri documentUri);
        Task<ResourceResponse<Document>> InsertAsync<T>(T document, Uri collectionUri);
    }
}