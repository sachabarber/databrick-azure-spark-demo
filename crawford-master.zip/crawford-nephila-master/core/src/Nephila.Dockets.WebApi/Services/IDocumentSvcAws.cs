﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Amazon.S3.Model;

namespace Nephila.Dockets.WebApi.Services
{
    public interface IDocumentSvcAws
    {
        Task<T> GetAsync<T>(string filePath);
        Task<PutObjectResponse> PutAsync(object o, string filePath, Dictionary<string, object> metadata);
    }
}