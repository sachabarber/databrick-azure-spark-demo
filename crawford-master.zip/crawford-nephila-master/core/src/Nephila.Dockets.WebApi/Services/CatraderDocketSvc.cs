﻿using Microsoft.Azure.Documents.Client;
using Microsoft.Azure.Documents.Linq;
using Microsoft.Extensions.Configuration;
using Nephila.Dockets.Shared.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Nephila.Dockets.WebApi.Services
{
    public class CatraderDocketSvc : ICatraderDocketSvc
    {
        private readonly IConfigurationRoot _configurationRoot;
        private DocumentClient _client;
        private const string DatabaseId = "docket";
        private const string CollectionId = "catraderimport";

        public CatraderDocketSvc(IConfigurationRoot configurationRoot)
        {
            _configurationRoot = configurationRoot;
            var endpointUri = _configurationRoot["Cosmos:Uri"];
            var key = _configurationRoot["Cosmos:Key"];
            _client = new DocumentClient(new Uri(endpointUri), key);
        }

        public async Task<CatraderEventSetDocket> GetEventSetsByEventSetIdAsync(string id)
        {
            return await _client.ReadDocumentAsync<CatraderEventSetDocket>(UriFactory.CreateDocumentUri(DatabaseId, CollectionId, id));
        }

        public async Task<IEnumerable<CatraderEventSetDocket>> GetEventSetsByDescriptionAsync(string description)
        {
            var dockets = new List<CatraderEventSetDocket>();

            var queryable = _client.CreateDocumentQuery<CatraderEventSetDocket>(UriFactory.CreateDocumentCollectionUri(DatabaseId, CollectionId))
                .Where(x => x.Description.ToUpper().Contains(description.ToUpper())).AsDocumentQuery();

            while (queryable.HasMoreResults)
            {
                var response = await queryable.ExecuteNextAsync<CatraderEventSetDocket>();
                dockets.AddRange(response);
            }

            return dockets;
        }

        public async Task<IEnumerable<CatraderEventSetDocket>> GetAllEventSetsAsync()
        {
            var dockets = new List<CatraderEventSetDocket>();

            var queryable = _client.CreateDocumentQuery<CatraderEventSetDocket>(UriFactory.CreateDocumentCollectionUri(DatabaseId, CollectionId))
                .ToAsyncEnumerable();

            return await queryable.ToList();
        }
    }
}
