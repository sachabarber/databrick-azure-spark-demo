﻿using System;
using System.Threading.Tasks;
using Nephila.Dockets.Shared.Models;
using System.Collections.Generic;

namespace Nephila.Dockets.WebApi.Services
{
    public interface IModellingResultSvcAws
    {
        Task<IEnumerable<SummaryStats>> GetAsync(Guid uid);
    }
}