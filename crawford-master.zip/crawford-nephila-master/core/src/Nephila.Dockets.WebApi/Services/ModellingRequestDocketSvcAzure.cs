﻿using AutoMapper;
using Microsoft.Azure.Documents;
using Microsoft.Azure.Documents.Client;
using Microsoft.Extensions.Configuration;
using Nephila.Dockets.Shared.Models;
using Nephila.Dockets.WebApi.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
namespace Nephila.Dockets.WebApi.Services
{
    public class ModellingRequestDocketSvcAzure : IModellingRequestDocketSvc
    {
        private readonly IDocumentSvcAzure _documentSvc;
        private readonly IMapper _mapper;
        private const string DatabaseId = "docket";
        private const string CollectionId = "modelling-requests";

        public ModellingRequestDocketSvcAzure(IConfigurationRoot configurationRoot,
            IMapper mapper,
            IDocumentSvcAzure documentSvc)
        {
            _documentSvc = documentSvc;
            _mapper = mapper;
        }

        public async Task<PutModellingResponse> PutAsync(CrawfordModelDocket docket)
        {            
            var metadata = new Dictionary<string, object>
            {
                { "Uid", docket.Id.ToString() },
                { "RequestedByUser", docket.RequestedByUser },
                { "RequestedDatetimeUtc", docket.RequestedDatetimeUtc.ToString() }
            };

            var collectionUri = UriFactory.CreateDocumentCollectionUri(DatabaseId, CollectionId);
            var response = await _documentSvc.InsertAsync(docket, collectionUri);
            return ConvertResponse(docket, response);
        }

        public async Task<GetModellingResponse> GetAsync(Guid documentUid)
        {
            var documentUri = UriFactory.CreateDocumentUri(DatabaseId, CollectionId, documentUid.ToString());
            return await GetAsync(documentUri);
        }

        public async Task<GetModellingResponse> GetAsync(Uri documentUri)
        {            
            var modellingDocket = await _documentSvc.GetAsync<CrawfordModelDocket>(documentUri);
            return _mapper.Map<GetModellingResponse>(modellingDocket);
        }

        private PutModellingResponse ConvertResponse(CrawfordModelDocket request, Document azureResponse)
        {
            var response = new PutModellingResponse
            {
                ETag = azureResponse.ETag,
                Id = new Guid(azureResponse.Id),
                DocumentUri = azureResponse.SelfLink,
            };

            return response;
        }
    }
}
