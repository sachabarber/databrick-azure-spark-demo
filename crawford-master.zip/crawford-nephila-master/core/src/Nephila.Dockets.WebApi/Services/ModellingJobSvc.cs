﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Azure.ServiceBus;
using Microsoft.Extensions.Configuration;
using Nephila.Dockets.Models;
using Nephila.Dockets.Models.Messages;
using Newtonsoft.Json;

namespace Nephila.Dockets.WebApi.Services
{
    public class ModellingJobSvc : IModellingJobSvc
    {
        private readonly IModellingRequestDocketSvc _modellingRequestDocketSvc;
        private readonly string _jobBusConnectionString;
        private readonly string _modellingTopicName;
        private readonly IQueueClient _queueClient;

        public ModellingJobSvc(IConfigurationRoot config,
            IModellingRequestDocketSvc modellingRequestDocketSvc)
        {
            _modellingRequestDocketSvc = modellingRequestDocketSvc;
            _jobBusConnectionString = config["JobBus:ConnectionString"];
            _modellingTopicName = config["JobBus:ModellingTopicName"];

            _queueClient = new QueueClient(_jobBusConnectionString, _modellingTopicName);
        }

        public async Task<DocketResponse> SubmitModellingJobAsync(ModellingRequest request)
        {
            var modellingDocketResponse = await _modellingRequestDocketSvc.PutAsync(request);

            var modellingMessage = new DatabricksJobRequestMsg
            {
                DatabricksRunRequest = new DatabricksRunRequest {
                    JobId = request.JobId,
                    RunParams = new DatabricksRunRequest.NotebookRunParams
                    {
                        ModellingDocketUid = modellingDocketResponse.Uid.ToString()
                    }
                },
                ModellingDocketPath = modellingDocketResponse.FileName,
                RequestedByUser = request.RequestedByUser,
                RequestedDatetimeUtc = request.RequestedDatetimeUtc,
                RequestUid = request.Uid,
            };

            string messageBody = JsonConvert.SerializeObject(modellingMessage);
            var message = new Message(Encoding.UTF8.GetBytes(messageBody));
            message.SessionId = Guid.NewGuid().ToString();

            await _queueClient.SendAsync(message);

            return modellingDocketResponse;
        }
    }
}
