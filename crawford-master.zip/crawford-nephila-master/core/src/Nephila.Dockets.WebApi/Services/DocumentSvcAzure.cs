﻿using Microsoft.Azure.Documents;
using Microsoft.Azure.Documents.Client;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Nephila.Dockets.WebApi.Services
{
    public class DocumentSvcAzure : IDocumentSvcAzure
    {
        private readonly IConfigurationRoot _configurationRoot;
        private DocumentClient _client;

        public DocumentSvcAzure(IConfigurationRoot configurationRoot)
        {
            _configurationRoot = configurationRoot;
            var endpointUri = _configurationRoot["Cosmos:Uri"];
            var key = _configurationRoot["Cosmos:Key"];
            _client = new DocumentClient(new Uri(endpointUri), key);
        }

        public async Task<ResourceResponse<Document>> InsertAsync<T>(T document, Uri collectionUri)
        {            
            return await _client.CreateDocumentAsync(collectionUri, document);
        }

        public async Task<T> GetAsync<T>(Uri documentUri)
        {
            return await _client.ReadDocumentAsync<T>(documentUri);
        }
    }
}
