﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Amazon.Runtime;
using Amazon.S3;
using Amazon.S3.Model;
using Microsoft.Azure.Documents;
using Microsoft.Azure.Documents.Client;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using Nephila.Dockets.WebApi.Models;
using Nephila.Dockets.Shared.Models;
using AutoMapper;

namespace Nephila.Dockets.WebApi.Services
{
    public class ModellingRequestDocketSvcAws : IModellingRequestDocketSvc
    {
        private readonly IDocumentSvcAws _documentSvcAws;
        private readonly IMapper _mapper;
        private const string _basePath = @"modelling-requests";

        public ModellingRequestDocketSvcAws(IConfigurationRoot configurationRoot,
            IMapper mapper,
            IDocumentSvcAws documentSvcAws)
        {
            _documentSvcAws = documentSvcAws;
            _mapper = mapper;
        }

        public async Task<PutModellingResponse> PutAsync(CrawfordModelDocket docket)
        {
            var filePath = GenerateFilePath(docket.Id);
            docket.FileName = filePath;

            var metadata = new Dictionary<string, object>
            {
                { "Uid", docket.Id.ToString() },
                { "RequestedByUser", docket.RequestedByUser },
                { "RequestedDatetimeUtc", docket.RequestedDatetimeUtc.ToString() }
            };

            var response = await _documentSvcAws.PutAsync(docket, filePath, metadata);
            return ConvertResponse(docket, response);
        }

        public async Task<GetModellingResponse> GetAsync(Guid uid)
        {
            var filePath = GenerateFilePath(uid);
            var responseBody = await _documentSvcAws.GetAsync<CrawfordModelDocket>(filePath);
            return _mapper.Map<GetModellingResponse>(responseBody);
        }

        private string GenerateFilePath(Guid uid)
        {
            var fileName = uid;
            return $"{_basePath}/{uid}/{fileName}.json";
        }

        private PutModellingResponse ConvertResponse(CrawfordModelDocket request, PutObjectResponse awsResponse)
        {
            var response = new PutModellingResponse
            {
                ETag = awsResponse.ETag,
                Id = request.Id,
            };

            return response;
        }

        public Task<GetModellingResponse> GetAsync(Uri documentUri)
        {
            throw new NotImplementedException();
        }
    }
}
