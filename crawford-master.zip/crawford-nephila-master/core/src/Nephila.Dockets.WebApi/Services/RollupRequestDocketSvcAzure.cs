﻿using AutoMapper;
using Microsoft.Azure.Documents;
using Microsoft.Azure.Documents.Client;
using Microsoft.Extensions.Configuration;
using Nephila.Dockets.Shared.Models;
using Nephila.Dockets.WebApi.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Nephila.Dockets.WebApi.Services
{
    public class RollupRequestDocketSvcAzure : IRollupRequestDocketSvc
    {
        private readonly IDocumentSvcAzure _documentSvc;
        private readonly IMapper _mapper;
        private const string DatabaseId = "docket";
        private const string CollectionId = "rollup-requests";
        private readonly Uri _collectionUri = UriFactory.CreateDocumentCollectionUri(DatabaseId, CollectionId);

        public RollupRequestDocketSvcAzure(IConfigurationRoot configurationRoot,
            IMapper mapper,
            IDocumentSvcAzure documentSvc)
        {
            _documentSvc = documentSvc;
            _mapper = mapper;
        }

        public async Task<PutRollupResponse> PutAsync(RollupModelDocket docket)
        {
            //var metadata = new Dictionary<string, object>
            //{
            //    { "Uid", docket.Id.ToString() },
            //    { "RequestedByUser", docket.RequestedByUser },
            //    { "RequestedDatetimeUtc", docket.RequestedDatetimeUtc.ToString() }
            //};

            var response = await _documentSvc.InsertAsync<RollupModelDocket>(docket, _collectionUri);
            return ConvertResponse(docket, response);
        }

        public async Task<GetRollupResponse> GetAsync(Uri documentUri)
        {
            var modellingDocket = await _documentSvc.GetAsync<RollupModelDocket>(documentUri);
            return _mapper.Map<GetRollupResponse>(modellingDocket);
        }

        public async Task<GetRollupResponse> GetAsync(Guid documentUid)
        {
            var documentUri = new Uri(_collectionUri, documentUid.ToString());
            return await GetAsync(documentUri);
        }

        private PutRollupResponse ConvertResponse(RollupModelDocket request, Document azureResponse)
        {
            var response = new PutRollupResponse
            {
                ETag = azureResponse.ETag,
                Id = new Guid(azureResponse.Id),
            };

            return response;
        }

        
    }
}
