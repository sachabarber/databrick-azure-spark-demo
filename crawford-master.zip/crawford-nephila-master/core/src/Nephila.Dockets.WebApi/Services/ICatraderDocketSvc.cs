﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Nephila.Dockets.Shared.Models;

namespace Nephila.Dockets.WebApi.Services
{
    public interface ICatraderDocketSvc
    {
        Task<CatraderEventSetDocket> GetEventSetsByEventSetIdAsync(string id);
        Task<IEnumerable<CatraderEventSetDocket>> GetAllEventSetsAsync();
        Task<IEnumerable<CatraderEventSetDocket>> GetEventSetsByDescriptionAsync(string description);
    }
}