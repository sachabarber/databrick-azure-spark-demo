﻿using System.Threading.Tasks;
using System;
using Nephila.Dockets.WebApi.Models;
using Nephila.Dockets.Shared.Models;

namespace Nephila.Dockets.WebApi.Services
{
    public interface IModellingRequestDocketSvc
    {
        Task<PutModellingResponse> PutAsync(CrawfordModelDocket docket);
        Task<GetModellingResponse> GetAsync(Uri documentUri);
        Task<GetModellingResponse> GetAsync(Guid documentUid);
    }
}