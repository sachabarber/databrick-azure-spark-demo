﻿using System;
using System.Collections.Generic;
using System.Linq;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Amazon.Runtime;
using Amazon.S3;
using Amazon.S3.Model;
using Microsoft.Azure.Documents;
using Microsoft.Azure.Documents.Client;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using Nephila.Dockets.WebApi.Models;
using Nephila.Dockets.Shared.Models;
using AutoMapper;
namespace Nephila.Dockets.WebApi.Services
{
    public class ModellingResultSvcAws : IModellingResultSvcAws
    {

        private readonly IDocumentSvcAws _documentSvcAws;
        private readonly IMapper _mapper;
        private const string _basePath = @"modelling-requests";

        public ModellingResultSvcAws(IConfigurationRoot configurationRoot,
            IMapper mapper,
            IDocumentSvcAws documentSvcAws)
        {
            _documentSvcAws = documentSvcAws;
            _mapper = mapper;
        }

        public async Task<IEnumerable<SummaryStats>> GetAsync(Guid uid)
        {
            var filePath = GenerateFilePath(uid);
            var responseBody = await _documentSvcAws.GetAsync<SummaryStats[]>(filePath);
            return responseBody;
        }

        private string GenerateFilePath(Guid uid)
        {
            var fileName = uid;
            return $"{_basePath}/{uid}/results/summary_stats.json";
        }
    }
}
