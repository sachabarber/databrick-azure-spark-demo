﻿using System;
using System.Threading.Tasks;
using Nephila.Dockets.Shared.Models;
using Nephila.Dockets.WebApi.Models;

namespace Nephila.Dockets.WebApi.Services
{
    public interface IRollupRequestDocketSvc
    {
        Task<GetRollupResponse> GetAsync(Guid uid);
        Task<PutRollupResponse> PutAsync(RollupModelDocket docket);
    }
}