﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Amazon.Runtime;
using Amazon.S3;
using Amazon.S3.Model;
using Microsoft.Azure.Documents;
using Microsoft.Azure.Documents.Client;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using Nephila.Dockets.WebApi.Models;
using Nephila.Dockets.Shared.Models;
using AutoMapper;

namespace Nephila.Dockets.WebApi.Services
{
    public class DocumentSvcAws : IDocumentSvcAws
    {
        private readonly IConfigurationRoot _configurationRoot;
        private IAmazonS3 _client;
        private readonly IMapper _mapper;
        private readonly string _accessKey;
        private readonly string _secretKey;
        private readonly string _bucketName;

        public DocumentSvcAws(IConfigurationRoot configurationRoot, IMapper mapper)
        {
            _configurationRoot = configurationRoot;
            _bucketName = _configurationRoot["AWS:S3BucketName"];
            _accessKey = _configurationRoot["AWS:S3AccessKey"];
            _secretKey = _configurationRoot["AWS:S3SecretKey"];

            var credentials = new BasicAWSCredentials(_accessKey, _secretKey);
            _client = new AmazonS3Client(credentials, Amazon.RegionEndpoint.USEast1);
            _mapper = mapper;
        }

        public async Task<PutObjectResponse> PutAsync(object o, 
            string filePath, 
            Dictionary<string, object> metadata)
        {
            try
            {
                var content = JsonConvert.SerializeObject(o);

                var putRequest = new PutObjectRequest
                {
                    BucketName = _bucketName,
                    ContentBody = content,
                    Key = filePath,
                };

                foreach (var key in metadata.Keys)
                {
                    putRequest.Metadata.Add(key, metadata[key].ToString());
                }
                

                var response = await _client.PutObjectAsync(putRequest);
                return response;
            }
            catch (AmazonS3Exception amazonS3Exception)
            {
                if (amazonS3Exception.ErrorCode != null &&
                    (amazonS3Exception.ErrorCode.Equals("InvalidAccessKeyId")
                     ||
                     amazonS3Exception.ErrorCode.Equals("InvalidSecurity")))
                {
                    Console.WriteLine("Check the provided AWS Credentials.");
                    Console.WriteLine(
                        "For service sign up go to http://aws.amazon.com/s3");
                }
            }

            return null;
        }

        public async Task<T> GetAsync<T>(string filePath)
        {
            try
            {
                var getRequest = new GetObjectRequest
                {
                    BucketName = _bucketName,
                    Key = filePath,
                };

                using (var response = await _client.GetObjectAsync(getRequest))
                using (var responseStream = response.ResponseStream)
                using (var reader = new StreamReader(responseStream))
                {
                    var responseBody = JsonConvert.DeserializeObject<T>(reader.ReadToEnd());
                    //responseBody.ETag = response.ETag;
                    return responseBody;
                }
            }
            catch (AmazonS3Exception amazonS3Exception)
            {
                if (amazonS3Exception.ErrorCode != null &&
                    (amazonS3Exception.ErrorCode.Equals("InvalidAccessKeyId")
                     ||
                     amazonS3Exception.ErrorCode.Equals("InvalidSecurity")))
                {
                    Console.WriteLine("Check the provided AWS Credentials.");
                    Console.WriteLine(
                        "For service sign up go to http://aws.amazon.com/s3");
                }
            }

            return default;
        }
    }
}
