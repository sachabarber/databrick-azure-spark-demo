﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Nephila.Dockets.WebApi.Models.Examples;
using Nephila.Dockets.WebApi.Services;
using Swashbuckle.AspNetCore.Examples;
using Microsoft.AspNetCore.Authorization;
using Nephila.Dockets.WebApi.Models;
using Nephila.Dockets.Shared.Models;
using AutoMapper;

namespace Nephila.Dockets.WebApi.Controllers
{
    [Produces("application/json")]
    [Route("api/v1/dockets/crawford/results")]
    //[Authorize]
    public class CrawfordResultsDocketsApiController : Controller
    {
        private readonly IModellingResultSvcAws _modellingResultSvcAws;
        private readonly IMapper _mapper;

        public CrawfordResultsDocketsApiController(IModellingResultSvcAws modellingResultSvcAws, IMapper mapper)
        {
            _modellingResultSvcAws = modellingResultSvcAws;
            _mapper = mapper;
        }
        
        [HttpGet]
        [Route("/api/v1/dockets/crawford/results/{uid}/summary-stats", Name = "GetCrawfordSummaryStatsDocketByUid")]
        public async Task<IActionResult> Get(Guid uid)
        {
            var docket = await _modellingResultSvcAws.GetAsync(uid);
            if (docket != null)
            {
                return Ok(docket);
            }
            else
            {
                return NotFound();
            }
        }
    }
}
