﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Nephila.Dockets.WebApi.Models.Examples;
using Nephila.Dockets.WebApi.Services;
using Swashbuckle.AspNetCore.Examples;
using Microsoft.AspNetCore.Authorization;
using Nephila.Dockets.WebApi.Models;
using Nephila.Dockets.Shared.Models;
using AutoMapper;

namespace Nephila.Dockets.WebApi.Controllers
{
    [Produces("application/json")]
    [Route("api/v1/dockets/rollup/models")]
    //[Authorize]
    public class RollupRequestController : Controller
    {
        private readonly IRollupRequestDocketSvc _docketSvc;
        private readonly IMapper _mapper;

        public RollupRequestController(IRollupRequestDocketSvc docketSvc, IMapper mapper)
        {
            _docketSvc = docketSvc;
            _mapper = mapper;
        }

        [HttpGet]
        [Route("/api/v1/dockets/rollup/models/{uid}", Name = "GetRollupRequestDocketByUid")]
        public async Task<IActionResult> Get(Guid uid)
        {
            var docket = await _docketSvc.GetAsync(uid);
            if (docket != null)
            {
                return Ok(docket);
            }
            else
            {
                return NotFound();
            }
        }

        [HttpPost]
        [Route("/api/v1/dockets/rollup/models")]
        [SwaggerRequestExample(typeof(PutRollupRequest), typeof(RollupRequestExample))]
        public async Task<IActionResult> Post([FromBody]PutRollupRequest value)
        {
            var mappedRequest = _mapper.Map<RollupModelDocket>(value);
            var docket = await _docketSvc.PutAsync(mappedRequest);

            return CreatedAtRoute("GetRollupRequestDocketByUid", new { uid = docket.Id }, docket);
        }
    }
}

