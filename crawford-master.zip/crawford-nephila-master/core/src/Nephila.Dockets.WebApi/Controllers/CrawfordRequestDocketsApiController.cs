﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Nephila.Dockets.WebApi.Models.Examples;
using Nephila.Dockets.WebApi.Services;
using Swashbuckle.AspNetCore.Examples;
using Microsoft.AspNetCore.Authorization;
using Nephila.Dockets.WebApi.Models;
using Nephila.Dockets.Shared.Models;
using AutoMapper;

namespace Nephila.Dockets.WebApi.Controllers
{
    [Produces("application/json")]
    [Route("api/v1/dockets/crawford/models")]
    //[Route("api/v1/dockets/crawford/models")]
    //[Authorize]
    public class CrawfordRequestDocketsApiController : Controller
    {
        private readonly IModellingRequestDocketSvc _modellingRequestDocketSvc;
        private readonly IMapper _mapper;

        public CrawfordRequestDocketsApiController(IModellingRequestDocketSvc modellingRequestDocketSvc, IMapper mapper)
        {
            _modellingRequestDocketSvc = modellingRequestDocketSvc;
            _mapper = mapper;
        }

        [HttpGet]
        [Route("/api/v1/dockets/crawford/models/{uid}", Name = "GetCrawfordModelDocketByUid")]
        public async Task<IActionResult> Get(Guid uid)
        {
            var docket = await _modellingRequestDocketSvc.GetAsync(uid);
            if (docket != null)
            {
                return Ok(docket);
            }
            else
            {
                return NotFound();
            }
        }

        [HttpPost]
        [Route("/api/v1/dockets/crawford/models")]
        [SwaggerRequestExample(typeof(PutModellingRequest), typeof(ModellingRequestExample))]
        public async Task<IActionResult> Post([FromBody]PutModellingRequest value)
        {
            var mappedRequest = _mapper.Map<CrawfordModelDocket>(value);
            var docket = await _modellingRequestDocketSvc.PutAsync(mappedRequest);

            return CreatedAtRoute("GetCrawfordModelDocketByUid", new { uid = docket.Id }, docket);
        }
    }
}
