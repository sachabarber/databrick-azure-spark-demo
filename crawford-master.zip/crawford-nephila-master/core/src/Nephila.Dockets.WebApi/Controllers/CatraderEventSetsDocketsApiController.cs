﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Nephila.Dockets.WebApi.Services;
using AutoMapper;
using Microsoft.Azure.Documents;

namespace Nephila.Dockets.WebApi.Controllers
{
    [Produces("application/json")]
    //[Authorize]
    public class CatraderEventSetsDocketsApiController : Controller
    {
        private readonly ICatraderDocketSvc _catraderDocketSvc;
        private readonly IMapper _mapper;

        public CatraderEventSetsDocketsApiController(ICatraderDocketSvc catraderDocketSvc, IMapper mapper)
        {
            _catraderDocketSvc = catraderDocketSvc;
            _mapper = mapper;
        }

        [HttpGet]
        [Route("api/v1/dockets/catrader/results/{id}",Name = "GetCatraderEventSetDocketById")]
        public async Task<IActionResult> Get(int id)
        {
            try
            {
                var docket = await _catraderDocketSvc.GetEventSetsByEventSetIdAsync(id.ToString());
                if (docket != null)
                {
                    return Ok(docket);
                }
                else
                {
                    return NotFound();
                }
            }
            catch (DocumentClientException dex) when (dex.StatusCode == System.Net.HttpStatusCode.NotFound)
            {
                return NotFound();
            }
        }

        [HttpGet]
        [Route("api/v1/dockets/catrader/results", Name = "GetCatraderEventSetDockets")]
        public async Task<IActionResult> Get()
        {
            var dockets = await _catraderDocketSvc.GetAllEventSetsAsync();
            if (dockets != null)
            {
                return Ok(dockets);
            }
            else
            {
                return NotFound();
            }
        }

        [HttpGet]
        [Route("api/v1/dockets/catrader/results/search/{description}", Name = "SearchCatraderEventSetDocketsByDescription")]
        public async Task<IActionResult> SearchByDescription(string description = null)
        {
            var dockets = await _catraderDocketSvc.GetEventSetsByDescriptionAsync(description);
            if (dockets != null)
            {
                return Ok(dockets);
            }
            else
            {
                return NotFound();
            }
        }


    }
}