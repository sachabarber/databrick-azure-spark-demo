﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Nephila.Dockets.WebApi.Services;
using Swashbuckle.AspNetCore.Examples;
using Swashbuckle.AspNetCore.Swagger;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.IdentityModel.Tokens;
using System.Text;
using Microsoft.AspNetCore.Authorization;
using Microsoft.EntityFrameworkCore;
using AutoMapper;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication.OpenIdConnect;

namespace Nephila.Dockets.WebApi
{
    public class Startup
    {
        private IHostingEnvironment _env;
        private readonly IConfigurationRoot _config;

        public Startup(IHostingEnvironment env)
        {
            var builder = new ConfigurationBuilder()
                .SetBasePath(env.ContentRootPath)
                .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true)
                .AddJsonFile($"appsettings.{env.EnvironmentName}.json", optional: true)
                .AddEnvironmentVariables();
            _env = env;
            _config = builder.Build();
        }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddAutoMapper();

            services.AddSingleton(_config);

            services.AddScoped<IDocumentSvcAws, DocumentSvcAws>();
            services.AddScoped<IDocumentSvcAzure, DocumentSvcAzure>();
            services.AddScoped<IModellingRequestDocketSvc, ModellingRequestDocketSvcAzure>();
            services.AddScoped<IModellingResultSvcAws, ModellingResultSvcAws>();
            services.AddScoped<ICatraderDocketSvc, CatraderDocketSvc>();
            services.AddScoped<IRollupRequestDocketSvc, RollupRequestDocketSvcAzure>();


            services.AddAuthentication(o =>
            {
                o.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
                o.DefaultScheme = JwtBearerDefaults.AuthenticationScheme;
                o.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
            })
            .AddJwtBearer(o =>
            {
                _config.Bind("AzureAd", o);
                o.Events = new JwtBearerEvents
                {
                    OnAuthenticationFailed = AuthFailed,
                    OnTokenValidated = TokenValidated
                };
                o.TokenValidationParameters = new TokenValidationParameters
                {
                    ValidAudiences = new List<string> {
                        "https://burnsjpgmail.onmicrosoft.com/c2940ba9-5cd5-4b9f-8376-63b4bc86c511",
                        "d1f920e0-79d4-42b0-9b95-4b530f02351a" },
                };
            });

            services.AddMvc(opt =>
            {
                if (_env.IsDevelopment())
                {
                    opt.SslPort = 44385;
                }

                //opt.Filters.Add(new RequireHttpsAttribute());
            });

            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new Info { Title = "Dockets API", Version = "v1" });
                c.AddSecurityDefinition("Bearer", new ApiKeyScheme
                {
                    Description = "JWT Authorization header using the Bearer scheme. Example: \"Authorization: Bearer {token}\"",
                    Name = "Authorization",
                    In = "header",
                    Type = "apiKey"
                });
                c.OperationFilter<ExamplesOperationFilter>();
            });
        }

        private Task TokenValidated(Microsoft.AspNetCore.Authentication.JwtBearer.TokenValidatedContext arg)
        {
            return Task.FromResult(0);
        }

        private Task AuthFailed(Microsoft.AspNetCore.Authentication.JwtBearer.AuthenticationFailedContext arg)
        {
            return Task.FromResult(0);
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseSwagger();

            // Enable middleware to serve swagger-ui (HTML, JS, CSS, etc.), specifying the Swagger JSON endpoint.

            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint("/swagger/v1/swagger.json", "Dockets API V1");
            });

            app.UseAuthentication();

            app.UseMvc();
        }
      
    }
}
