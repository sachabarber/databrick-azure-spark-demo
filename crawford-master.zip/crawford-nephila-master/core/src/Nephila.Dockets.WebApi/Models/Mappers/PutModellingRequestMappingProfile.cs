﻿using AutoMapper;
using Nephila.Dockets.Shared.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Nephila.Dockets.WebApi.Models.Mappers
{
    public class PutModellingRequestMappingProfile : Profile
    {
        public PutModellingRequestMappingProfile()
        {
            CreateMap<PutModellingRequest, CrawfordModelDocket>()
                .ForMember(dest => dest.RequestedDatetimeUtc, o => o.MapFrom(src => DateTime.UtcNow))
                .ForMember(dest => dest.Id, o => o.MapFrom(src => Guid.NewGuid()));
        }
    }
}
