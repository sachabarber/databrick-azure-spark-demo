﻿using AutoMapper;
using Microsoft.Azure.Documents;
using Nephila.Dockets.Shared.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Nephila.Dockets.WebApi.Models.Mappers
{
    public class GetModellingResponseMappingProfile : Profile
    {
        public GetModellingResponseMappingProfile()
        {
            CreateMap<GetModellingResponse, CrawfordModelDocket>();          
        }
    }
}
