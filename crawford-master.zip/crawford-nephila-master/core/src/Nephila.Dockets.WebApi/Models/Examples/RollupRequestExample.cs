﻿using Nephila.Dockets.Shared.Models;
using Swashbuckle.AspNetCore.Examples;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Nephila.Dockets.WebApi.Models.Examples
{
    public class RollupRequestExample : IExamplesProvider
    {
        public object GetExamples()
        {
            return new PutRollupRequest
            {
                RequestedByUser = "jburns",
                RollupItems = new List<RollupItem>
                {
                    new RollupItem
                    {
                        EventSetId = 105670,
                        Limit = 1E6,
                        EventSetSource = "Crawford",
                        Allocations = new List<Allocation>
                        {
                            new Allocation
                            {
                                AllocationPercentage = 1.0m,
                                Name = "My Portfolio",
                            }
                        }
                    }
                }
            };
        }
    }
}
