﻿using System;
using Swashbuckle.AspNetCore.Examples;
using Nephila.Dockets.Shared.Models;

namespace Nephila.Dockets.WebApi.Models.Examples
{
    public class ModellingRequestExample : IExamplesProvider
    {
        public object GetExamples()
        {
            return new PutModellingRequest
            {
                EventSetId = 105670,
                EventSetSource = "CATRADER",
                TriggerType = "OCC_SINGLE",
                Excess = 15 * 1E9,
                Limit = 50 * 1E9,
                RequestedByUser = "jburns",
            };
        }
    }
}
