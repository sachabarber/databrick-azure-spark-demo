﻿using Microsoft.Azure.Documents;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace Nephila.Dockets.WebApi.Models
{
    public abstract class DocketBase
    {
        [JsonProperty(PropertyName = "id")]
        public Guid Id { get; set; }
        public string FileName { get; set; }
        public string RequestedByUser { get; set; }
        public DateTime RequestedDatetimeUtc { get; set; }
    }
}
