﻿using System;

namespace Nephila.Dockets.WebApi.Models
{
    public class CrawfordModelDocket : DocketBase
    {
        public double Limit { get; set; }
        public double Excess { get; set; }
        public string TriggerType { get; set; }
        public int EventSetId { get; set; }
        public string EventSetSource { get; set; }
    }
}
