﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Nephila.Dockets.WebApi.Models
{
    public class DocketResponse : DocketBase
    {
    }
}
