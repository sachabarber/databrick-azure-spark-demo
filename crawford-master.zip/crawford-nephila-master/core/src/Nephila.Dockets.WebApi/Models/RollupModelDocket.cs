﻿using Nephila.Dockets.Shared.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Nephila.Dockets.WebApi.Models
{
    public class RollupModelDocket : DocketBase
    {
        public IEnumerable<RollupItem> RollupItems { get; set; }
    }
}
