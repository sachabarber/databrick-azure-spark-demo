﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Nephila.StaticData.Shared.Models;

namespace Nephila.StaticData.WebApi.Controllers
{
    [Route("api/static/v1/metarisks")]
    public class MetaRisksController : Controller
    {
        [HttpGet]
        [Route("api/static/v1/metarisks")]
        public async Task<IActionResult> Get()
        {
            var metaRisks = await Task.Run(() => { return new List<MetaRisk> { new MetaRisk { Name = "Worldwide", Id = 51 }} ;});
            return Ok(metaRisks);
        }
        
        [HttpGet]
        [Route("api/static/v1/metarisks/{name}")]
        public async Task<IActionResult> Get(string name)
        {
            var metaRisk = await Task.Run(() => { return new MetaRisk { Name = name, Id = 1 }; });
            return Ok(metaRisk);
        }

        [HttpGet]
        [Route("api/static/v1/metarisks/{id}/subareas")]
        public async Task<IActionResult> GetSubAreas(int id)
        {
            var metaRisk = await Task.Run(() => { return new MetaRisk { Id = id }; });

            return Ok(metaRisk);
        }
    }
}
