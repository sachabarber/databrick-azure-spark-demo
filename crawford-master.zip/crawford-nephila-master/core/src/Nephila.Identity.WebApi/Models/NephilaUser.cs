﻿using Microsoft.AspNetCore.Identity;
using System;

namespace Nephila.Identity.WebApi.Models
{
    public class NephilaUser : IdentityUser
    {
        public NephilaUser()
        {
        }
    }
}
