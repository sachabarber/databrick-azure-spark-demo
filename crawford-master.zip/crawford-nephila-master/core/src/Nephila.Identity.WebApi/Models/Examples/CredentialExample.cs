﻿using Swashbuckle.AspNetCore.Examples;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Nephila.Identity.WebApi.Models.Examples
{
    public class CredentialExample : IExamplesProvider
    {
        public object GetExamples()
        {
            return new Credential
            {
                UserName = "nephila",
                Password = "Sp1d3rs!",
            };
        }
    }
}
