﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Nephila.Identity.WebApi.Models
{
    public class UserDbContext : IdentityDbContext<NephilaUser>
    {
        private IConfigurationRoot _config;

        public UserDbContext(DbContextOptions options, IConfigurationRoot config) : base(options)
        {
            _config = config;
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            base.OnConfiguring(optionsBuilder);

            optionsBuilder.UseSqlServer(_config["UserDb:ConnectionString"]);
        }

    }
}
