﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.IdentityModel.Tokens;
using Nephila.Identity.WebApi.Models;
using Nephila.Identity.WebApi.Models.Examples;
using Nephila.Identity.WebApi.Services;
using Swashbuckle.AspNetCore.Examples;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

namespace Nephila.Identity.WebApi.Controllers
{
    [Produces("application/json")]
    [Route("api/v1/auth")]
    public class AuthController : BaseController
    {
        private readonly UserDbContext _ctx;
        private readonly SignInManager<NephilaUser> _signInMgr;
        private readonly ILogger<AuthController> _logger;
        private readonly UserManager<NephilaUser> _userManager;
        private readonly IPasswordHasher<NephilaUser> _passwordHasher;
        private readonly IConfigurationRoot _config;

        public AuthController(UserDbContext ctx,
            SignInManager<NephilaUser> signInMgr,
            ILogger<AuthController> logger,
            UserManager<NephilaUser> userManager,
            IPasswordHasher<NephilaUser> passwordHasher,
            IConfigurationRoot config)
        {
            _ctx = ctx;
            _signInMgr = signInMgr;
            _logger = logger;
            _userManager = userManager;
            _passwordHasher = passwordHasher;
            _config = config;
        }

        [HttpPost]
        [Route("token")]
        [SwaggerRequestExample(typeof(Credential), typeof(CredentialExample))]
        public async Task<IActionResult> CreateToken([FromBody] Credential model)
        {
            try
            {
                var user = await _userManager.FindByNameAsync(model.UserName);

                if (user != null)
                {
                    if (_passwordHasher.VerifyHashedPassword(user, user.PasswordHash, model.Password) == PasswordVerificationResult.Success)
                    {
                        var userClaims = await _userManager.GetClaimsAsync(user);

                        var claims = new[]
                        {
                            new Claim(JwtRegisteredClaimNames.Sub, user.UserName),
                            new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
                        }.Union(userClaims);

                        var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_config["Tokens:Key"]));
                        var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

                        var token = new JwtSecurityToken(
                             issuer: _config["Tokens:Issuer"],
                             audience: _config["Tokens:Audience"],
                             claims: claims,
                             expires: DateTime.UtcNow.AddHours(4),
                             signingCredentials: creds);

                        return Ok(new { token = new JwtSecurityTokenHandler().WriteToken(token), expiration = token.ValidTo });
                    }
                }

                var result = await _signInMgr.PasswordSignInAsync(model.UserName, model.Password, false, false);

                if (result.Succeeded)
                {
                    return Ok();
                }
            }
            catch (Exception ex)
            {
                _logger.LogInformation($"Token creation failed for {model.UserName}");
            }

            return BadRequest("Failed to generate token");
        }

    }
}
