﻿using Microsoft.EntityFrameworkCore;
using Nephila.Identity.WebApi.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Nephila.Identity.WebApi.Services
{
    public class UserRepository
    {
        protected readonly UserDbContext _ctx;

        public UserRepository(UserDbContext ctx)
        {
            _ctx = ctx;
        }

        public async Task<NephilaUser> GetUserAsync(string userName)
        {
            return await _ctx.Users
              .Where(u => u.UserName == userName)
              .Cast<NephilaUser>()
              .FirstOrDefaultAsync();
        }
    }
}
