﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Nephila.Crawford.Web.Services;
using AutoMapper;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication.OpenIdConnect;
using Microsoft.IdentityModel.Protocols.OpenIdConnect;
using Microsoft.IdentityModel.Tokens;
using Microsoft.AspNetCore.Http;

namespace Nephila.Crawford.Web
{
    public class Startup
    {
        private IHostingEnvironment _env;
        private readonly IConfigurationRoot _config;

        public Startup(IHostingEnvironment env)
        {
            var builder = new ConfigurationBuilder()
                .SetBasePath(env.ContentRootPath)
                .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true)
                .AddJsonFile($"appsettings.{env.EnvironmentName}.json", optional: true)
                .AddEnvironmentVariables();
            _env = env;
            _config = builder.Build();
        }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddSingleton(_config);
            services.AddLogging();
            services.AddScoped<ICrawfordJobWebApiClient, CrawfordJobWebApiClient>();
            services.AddScoped<IDocketsWebApiClient, DocketsWebApiClient>();
            services.AddScoped<IModellingService, ModellingService>();
            services.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();

            services.AddAutoMapper();

            services.AddAuthentication(options =>
            { 
                options.DefaultScheme = CookieAuthenticationDefaults.AuthenticationScheme;
                options.DefaultChallengeScheme = OpenIdConnectDefaults.AuthenticationScheme;
            })
            .AddOpenIdConnect(options =>
            {
                _config.Bind("AzureAd", options);
                options.ResponseType = OpenIdConnectResponseType.IdToken;
                options.SaveTokens = true;               
                options.Events = new OpenIdConnectEvents
                {
                    OnRemoteFailure = RemoteFailure,
                    OnTokenValidated = TokenValidated,    
                    
                };
                //options.TokenValidationParameters = new TokenValidationParameters
                //{
                //    // Instead of using the default validation (validating against
                //    // a single issuer value, as we do in line of business apps), 
                //    // we inject our own multitenant validation logic
                //    ValidateIssuer = false,

                //    NameClaimType = "name"
                //};
            })
            .AddCookie(options =>
            {
                options.SlidingExpiration = true;           
                options.Events = new CookieAuthenticationEvents
                {
                    OnValidatePrincipal = context =>
                    {
                        if (context.Properties.Items.ContainsKey(".Token.expires_at"))
                        {
                            var expire = DateTime.Parse(context.Properties.Items[".Token.expires_at"]);
                            if (expire > DateTime.Now) //TODO:change to check expires in next 5 mintues.
                            {
                                context.ShouldRenew = true;
                            }
                        }
                        return Task.FromResult(0);
                    }
                };
            });
       
            services.AddMvc();
        }

        private Task TokenValidated(TokenValidatedContext context)
        {
            /* ---------------------
            // Replace this with your logic to validate the issuer/tenant
               ---------------------       
            // Retriever caller data from the incoming principal
            string issuer = context.SecurityToken.Issuer;
            string subject = context.SecurityToken.Subject;
            string tenantID = context.Ticket.Principal.FindFirst("http://schemas.microsoft.com/identity/claims/tenantid").Value;

            // Build a dictionary of approved tenants
            IEnumerable<string> approvedTenantIds = new List<string>
            {
                "<Your tenantID>",
                "9188040d-6c67-4c5b-b112-36a304b66dad" // MSA Tenant
            };

            if (!approvedTenantIds.Contains(tenantID))
                throw new SecurityTokenValidationException();
              --------------------- */

            return Task.FromResult(0);
        }

        // Handle sign-in errors differently than generic errors.
        private Task RemoteFailure(object context)
        {
            //context.HandleResponse();
            //context.Response.Redirect("/Home/Error?message=" + context.Failure.Message);
            return Task.FromResult(0);
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
                app.UseBrowserLink();
            }
            else
            {
                app.UseExceptionHandler("/Home/Error");
            }

            
            app.UseStaticFiles();

            app.UseAuthentication();

            app.UseMvc(routes =>
            {
                routes.MapRoute(
                    name: "default",
                    template: "{controller=Home}/{action=Index}/{id?}");
            });
        }
    }
}
