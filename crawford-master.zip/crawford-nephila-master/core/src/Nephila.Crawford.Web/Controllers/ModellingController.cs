﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Nephila.Crawford.Web.Services;
using AutoMapper;
using Nephila.Crawford.Web.Models;
using Microsoft.AspNetCore.Authorization;

namespace Nephila.Crawford.Web.Controllers
{
    [Authorize]
    public class ModellingController : Controller
    {
        private readonly IModellingService _modellingService;

        public ModellingController(IModellingService modellingService)
        {
            _modellingService = modellingService;
        }
        // GET: Modeling
        public async Task<ActionResult> Index()
        {
            var jobs = await _modellingService.GetAllJobsAsync();
            return View(jobs);
        }

        // GET: Modeling/Details/5
        public async Task <ActionResult> Details(int id)
        {
            var jobStatus = await _modellingService.GetJobStatusAsync(id);
            return View(jobStatus);
        }


        public async Task<ActionResult> Results(Guid uid)
        {
            var results = await _modellingService.GetResultsAsync(uid);
            return View(results);
        }

        // GET: Modeling/Create
        public ActionResult Create()
        {
            var sampleModel = new LayerModel
            {
                EventSetId = 105670,
                EventSetSource = "CATRADER",
                TriggerType = "OCC_SINGLE",
                Excess = 15 * 1E9,
                Limit = 50 * 1E9,
                Engine = "Databricks",
                RequestedByUser = "jburns",
                JobType = "CRAWFORD",
            };

            return View(sampleModel);
        }

        // POST: Modeling/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Create(LayerModel model)
        {
            try
            {
                var response = await _modellingService.SubmitModellingJobAsync(model);

                return RedirectToAction(nameof(Details), new { id = response.Id });
            }
            catch
            {
                return View();
            }
        }
    }
}