﻿using AutoMapper;
using Nephila.Crawford.Web.Models;
using Nephila.Databricks.Job.Shared.Models;
using Nephila.Dockets.Shared.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Nephila.Crawford.Web.Services
{
    public class ModellingService : IModellingService
    {
        private IDocketsWebApiClient _docketsApiWebClient;
        private ICrawfordJobWebApiClient _databricksJobWebApiClient;
        private readonly IMapper _mapper;

        public ModellingService(IDocketsWebApiClient docketsApiWebClient, 
            ICrawfordJobWebApiClient databricksJobWebApiClient,
            IMapper mapper)
        {
            _docketsApiWebClient = docketsApiWebClient;
            _databricksJobWebApiClient = databricksJobWebApiClient;
            _mapper = mapper;
        }

        public async Task<JobStatusModel> SubmitModellingJobAsync(LayerModel layer)
        {
            var putModellingRequest = _mapper.Map<PutModellingRequest>(layer);
            var modellingResponse = await _docketsApiWebClient.PostModellingRequestAsync(putModellingRequest);
            var jobResponse = await _databricksJobWebApiClient.PostCrawfordJobAsync(new PutDatabricksJobRequest
            {
                ModelDocketUid = modellingResponse.DocumentUri,
                RequestedByUser = layer.RequestedByUser,
                JobType = layer.JobType,
            });
            var jobStatus = _mapper.Map<JobStatusModel>(jobResponse);
            return jobStatus;
        }

        public async Task<JobStatusModel> GetJobStatusAsync(int id)
        {
            var jobResponse = await _databricksJobWebApiClient.GetCrawfordJobAsync(id);
            var jobStatus = _mapper.Map<JobStatusModel>(jobResponse);
            return jobStatus;
        }

        public async Task<IEnumerable<JobStatusModel>> GetAllJobsAsync()
        {
            var jobResponse = await _databricksJobWebApiClient.GetAllCrawfordJobsAsync();
            var jobStatus = jobResponse.Select(x => _mapper.Map<JobStatusModel>(x));
            return jobStatus;
        }

        public async Task<ModelResultsModel> GetResultsAsync(Guid uid)
        {
            var results = await _docketsApiWebClient.GetModellingResultsAsync(uid);
           
            return new ModelResultsModel { SummaryStats = results };
        }
    }
}
