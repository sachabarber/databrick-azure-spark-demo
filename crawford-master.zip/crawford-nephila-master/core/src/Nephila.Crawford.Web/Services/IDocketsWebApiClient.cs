﻿using System.Threading.Tasks;
using Nephila.Dockets.Shared.Models;
using System;
using System.Collections.Generic;

namespace Nephila.Crawford.Web.Services
{
    public interface IDocketsWebApiClient
    {
        Task<PutModellingResponse> PostModellingRequestAsync(PutModellingRequest model);
        Task<IEnumerable<SummaryStats>> GetModellingResultsAsync(Guid modellingDocketUid);
    }
}