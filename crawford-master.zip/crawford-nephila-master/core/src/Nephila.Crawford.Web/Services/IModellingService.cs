﻿using System.Threading.Tasks;
using Nephila.Crawford.Web.Models;
using System;
using Nephila.Dockets.Shared.Models;
using System.Collections.Generic;

namespace Nephila.Crawford.Web.Services
{
    public interface IModellingService
    {
        Task<JobStatusModel> SubmitModellingJobAsync(LayerModel layer);
        Task<JobStatusModel> GetJobStatusAsync(int id);
        Task<IEnumerable<JobStatusModel>> GetAllJobsAsync();
        Task<ModelResultsModel> GetResultsAsync(Guid uid);
    }
}