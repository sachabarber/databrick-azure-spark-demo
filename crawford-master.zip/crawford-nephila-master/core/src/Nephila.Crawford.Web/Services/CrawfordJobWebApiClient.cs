﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Authentication;
using Microsoft.Extensions.Configuration;
using Nephila.Databricks.Job.Shared.Models;
using Nephila.Dockets.Shared.Models;
using RestSharp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.IdentityModel.Protocols.OpenIdConnect;
using Microsoft.Extensions.Logging;

namespace Nephila.Crawford.Web.Services
{
    public class CrawfordJobWebApiClient : ICrawfordJobWebApiClient
    {
        private readonly IConfigurationRoot _configuration;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly string _url;
        private readonly ILogger _logger;
        private readonly string _token;
        private readonly RestClient _client;

        public CrawfordJobWebApiClient(IConfigurationRoot configuration, 
            IHttpContextAccessor httpContextAccessor,
            ILoggerFactory logger)
        {
            _configuration = configuration;
            _httpContextAccessor = httpContextAccessor;
            _url = configuration["DatabricksJobsApi:Url"];
            _logger = logger.CreateLogger<CrawfordJobWebApiClient>();
          
            _client = new RestClient(_url);
        }

        public async Task<DatabricksJobResponse> PostCrawfordJobAsync(PutDatabricksJobRequest job)
        {
            var request = new RestSharp.Serializers.Newtonsoft.Json.RestRequest("api/v1/jobs/databricks/crawford", Method.POST);
            request.AddJsonBody(job);
            await AddTokenAsync(request);
            var response = await _client.ExecuteTaskAsync<DatabricksJobResponse>(request);

            return response.Data;
        }

        public async Task<DatabricksJobResponse> GetCrawfordJobAsync(int jobId)
        {
            var request = new RestSharp.Serializers.Newtonsoft.Json.RestRequest("api/v1/jobs/databricks/crawford/{id}", Method.GET);
            request.AddUrlSegment("id", jobId.ToString());
            await AddTokenAsync(request);
            var response = await _client.ExecuteTaskAsync<DatabricksJobResponse>(request);

            return response.Data;
        }

        public async Task<IEnumerable<DatabricksJobResponse>> GetAllCrawfordJobsAsync()
        {            
            var request = new RestSharp.Serializers.Newtonsoft.Json.RestRequest("api/v1/jobs/databricks/crawford", Method.GET);
            await AddTokenAsync(request);
            var response = await _client.ExecuteTaskAsync<IEnumerable<DatabricksJobResponse>>(request);

            if (!response.IsSuccessful)
            {
                throw new Exception($"{response.ResponseStatus}: {response.StatusDescription}");
            }

            return response.Data;
        }

        private async Task<RestSharp.Serializers.Newtonsoft.Json.RestRequest> AddTokenAsync(RestSharp.Serializers.Newtonsoft.Json.RestRequest request)
        {
            var token = await _httpContextAccessor.HttpContext.GetTokenAsync(OpenIdConnectResponseType.IdToken);
            
            _logger.LogDebug($"Token: {token}");

            request.AddHeader("Authorization", $"bearer {token}");
            request.AddHeader("Accept", "application/json");
            return request;
        }
    }
}
