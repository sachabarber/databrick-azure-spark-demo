﻿using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Protocols.OpenIdConnect;
using Nephila.Dockets.Shared.Models;
using RestSharp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

namespace Nephila.Crawford.Web.Services
{
    public class DocketsWebApiClient : IDocketsWebApiClient
    {
        private readonly IConfigurationRoot _configuration;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly string _url;        
        private readonly string _token;
        private readonly RestClient _client;

        public DocketsWebApiClient(IConfigurationRoot configuration, IHttpContextAccessor httpContextAccessor)
        {
            _configuration = configuration;
            _url = configuration["DocketsApi:Url"];
            _httpContextAccessor = httpContextAccessor;
            _client = new RestClient(_url);
        }

        public async Task<PutModellingResponse> PostModellingRequestAsync(PutModellingRequest model)
        {
            var request = new RestSharp.Serializers.Newtonsoft.Json.RestRequest("api/v1/dockets/models", Method.POST);
            request.AddJsonBody(model);
            await AddTokenAsync(request);
            var response = await _client.ExecuteTaskAsync<PutModellingResponse>(request);

            if (response.StatusCode == HttpStatusCode.Unauthorized)
            {
                await _httpContextAccessor.HttpContext.ChallengeAsync();
            }

            return response.Data;
        }

        public async Task<PutRollupResponse> PostRollupRequestAsync(PutRollupRequest model)
        {
            var request = new RestSharp.Serializers.Newtonsoft.Json.RestRequest("api/v1/dockets/rollup", Method.POST);
            request.AddJsonBody(model);
            await AddTokenAsync(request);
            var response = await _client.ExecuteTaskAsync<PutRollupResponse>(request);

            if (response.StatusCode == HttpStatusCode.Unauthorized)
            {
                await _httpContextAccessor.HttpContext.ChallengeAsync();
            }

            return response.Data;
        }

        public async Task<IEnumerable<SummaryStats>> GetModellingResultsAsync(Guid modellingDocketUid)
        {
            var request = new RestSharp.Serializers.Newtonsoft.Json.RestRequest("api/v1/dockets/models/{uid}/results/summary-stats", Method.GET);
            request.AddUrlSegment("uid", modellingDocketUid.ToString());
            await AddTokenAsync(request);
            var response = await _client.ExecuteTaskAsync<IEnumerable<SummaryStats>>(request);

            if (response.StatusCode == HttpStatusCode.Unauthorized)
            {
                await _httpContextAccessor.HttpContext.ChallengeAsync();
            }

            return response.Data;
        }

        private async Task<RestSharp.Serializers.Newtonsoft.Json.RestRequest> AddTokenAsync(RestSharp.Serializers.Newtonsoft.Json.RestRequest request)
        {
            var token = await _httpContextAccessor.HttpContext.GetTokenAsync(OpenIdConnectResponseType.IdToken);
            
            request.AddHeader("Authorization", $"bearer {token}");
            request.AddHeader("Accept", "application/json");
            return request;
        }
    }
}
