﻿using System.Threading.Tasks;
using Nephila.Databricks.Job.Shared.Models;
using System.Collections.Generic;

namespace Nephila.Crawford.Web.Services
{
    public interface ICrawfordJobWebApiClient
    {
        Task<DatabricksJobResponse> GetCrawfordJobAsync(int jobId);
        Task<DatabricksJobResponse> PostCrawfordJobAsync(PutDatabricksJobRequest job);
        Task<IEnumerable<DatabricksJobResponse>> GetAllCrawfordJobsAsync();
    }
}