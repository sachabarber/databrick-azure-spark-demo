﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Nephila.Crawford.Web.Models
{
    public class JobStatusModel
    {
        public int Id { get; set; }
        public string ModellingDocketUid { get; set; }
        public int JobId { get; set; }
        public string Status { get; set; }
        public string ExceptionDetails { get; set; }
        public int? RunId { get; set; }
        public string RequestedByUser { get; set; }
        public DateTime DateTimeAddedUtc { get; set; }
        public DateTime DateTimeLastUpdatedUtc { get; set; }
    }
}
