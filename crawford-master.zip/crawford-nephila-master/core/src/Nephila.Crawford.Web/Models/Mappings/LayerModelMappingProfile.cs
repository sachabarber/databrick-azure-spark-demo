﻿using AutoMapper;
using Nephila.Dockets.Shared.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Nephila.Crawford.Web.Models.Mappings
{
    public class LayerModelMappingProfile : Profile
    {
        public LayerModelMappingProfile()
        {
            CreateMap<LayerModel, PutModellingRequest>();
        }
    }
}
