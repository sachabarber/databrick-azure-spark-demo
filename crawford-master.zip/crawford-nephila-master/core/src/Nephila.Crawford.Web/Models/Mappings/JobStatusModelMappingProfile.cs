﻿using AutoMapper;
using Nephila.Databricks.Job.Shared.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Nephila.Crawford.Web.Models.Mappings
{
    public class JobStatusModelMappingProfile : Profile
    {
        public JobStatusModelMappingProfile()
        {
            CreateMap<DatabricksJobResponse, JobStatusModel>();
        }
    }
}
