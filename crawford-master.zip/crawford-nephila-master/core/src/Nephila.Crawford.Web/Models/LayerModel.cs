﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Nephila.Crawford.Web.Models
{
    public class LayerModel
    {
        [DisplayFormat(DataFormatString = "{0:N}")]
        public double Limit { get; set; }
        [DisplayFormat(DataFormatString = "{0:N}")]
        public double Excess { get; set; }

        public string TriggerType { get; set; }
        public int EventSetId { get; set; }
        public string EventSetSource { get; set; }
        public string Engine { get; set; }
        public string RequestedByUser { get; set; }
        public string JobType { get; set; }
    }
}
