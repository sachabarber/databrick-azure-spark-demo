﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.IO;
using System.Threading.Tasks;
using CsvHelper;
using Dapper;
using Nephila.EventSetExtractor.Services.Models;

namespace Nephila.EventSetExtractor.Services
{
    public class CatraderExtractor
    {
        private readonly string _connectionString;

        public CatraderExtractor(string connectionString)
        {
            _connectionString = connectionString;
        }

        public void SaveEventLossesAsCsv(CatraderEventSetHeader header, string dataFolder)
        {
            var sql = $@"SELECT DISTINCT
                {header.EventSetId} as EventSetId
                ,t031_id as GeoId
                ,el.t010_id as PerilId
                ,t015_id as LobId
                ,el.event_id as EventId
                ,e.event_year as [Simulation]
                ,e.event_day as [EventDay]	
                ,el.ground_up_loss_inc_ds as Loss
                FROM {header.LossSource} el
                INNER JOIN {header.EventSource} e 
                ON el.event_parent_checksum = e.event_checksum
                ORDER BY Simulation, EventDay, EventId, GeoId, PerilId, LobId";

            var proposedPath = Path.Combine(dataFolder, header.EventSetId.ToString());
            Directory.CreateDirectory(proposedPath);
            var savePath = Path.Combine(proposedPath, $"{header.EventSetId}.csv");



            using (var conn = new SqlConnection(_connectionString))
            {
                var results = conn.Query<CatraderEventLoss>(sql, buffered: false, commandTimeout: 60000);

                using (StreamWriter writer = File.CreateText(savePath))
                {
                    var csv = new CsvWriter(writer);
                    csv.Configuration.RegisterClassMap<CatraderEventLossCsvMapping>();
                    csv.WriteRecords(results);
                }
            }

        }



        public async Task<IEnumerable<CatraderEventSetHeader>> ExtractHeadersAsync(string ids)
        {
            var sql = $@"SELECT 
                t061_id as EventSetId 
                ,t061_reference as Description 
                ,e.t060_id as SourceVersionId
                ,t061_id as ModelId 
                ,t061_id as SourceId 
                ,t060_source_system as SourceSystem
                ,t060_source_version as SourceVersion 
                ,t061_simulation_count as SimulationCount
                ,t061_date_imported as CreatedDateUtc
                ,t061_create_user as CreatedBy
                ,t061_eventset_xml as AdditionalInfo
                ,CONCAT(t061_eventset_database,'.',t061_eventset_db_owner,'.',t061_eventset_loss_table) as LossSource
                ,CASE WHEN (PatIndex('%_Loss%', t061_eventset_database) > 0) THEN CONCAT(REPLACE(t061_eventset_database, Substring(t061_eventset_database, PatIndex('%_Loss%', t061_eventset_database), 6), '_Vendor'),'.',t061_eventset_db_owner,'.',CONCAT('t',t061_parent_id,'_event')) 
				ELSE CONCAT(t061_eventset_database, '.', t061_eventset_db_owner,'.',CONCAT('t',t061_id,'_event')) END as EventSource
                ,efc.t052_name as EventFactorClassification
                FROM [dbo].[t061_event_set] es
                INNER JOIN [OPTISIMDB_Eventsets].[dbo].[t060_event_source] e 
                ON es.t060_id = e.t060_id 
                INNER JOIN [dbo].[t052_event_factor_classification] efc 
                ON efc.t052_id = es.t052_id 
                WHERE t061_id IN ({ids})
                order by t061_date_imported desc";

            using (var conn = new SqlConnection(_connectionString))
            {
                var catraderHeaders = await conn.QueryAsync<CatraderEventSetHeader>(sql);
                return catraderHeaders;
            }
        }

    }
}
