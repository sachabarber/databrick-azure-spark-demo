﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CsvHelper;
using Dapper;
using Nephila.EventSetExtractor.Services.Models;

namespace Nephila.EventSetExtractor.Services
{
    public class CalculatorExtractor
    {
        private readonly string _connectionString;

        public CalculatorExtractor(string connectionString)
        {
            _connectionString = connectionString;
        }


        public void SaveEventLossesAsCsv(CalculatorEventSetHeader header, string dataFolder)
        {
            var dynamicParameters = new DynamicParameters();
            dynamicParameters.Add("@EventSetId", header.EventSetId);
            dynamicParameters.Add("@payoutUid", header.PayoutUid);
            dynamicParameters.Add("@payoutVersion", DateTime.UtcNow);


            var sql = $@"OPTISIMDB_Calc.[riskstore].[proc_GetEventSetLoss]";

            var proposedPath = Path.Combine(dataFolder, header.EventSetId.ToString());
            Directory.CreateDirectory(proposedPath);
            var savePath = Path.Combine(proposedPath, $"{header.EventSetId}.csv");


            using (var conn = new SqlConnection(_connectionString))
            {
                var results = conn.Query(sql, dynamicParameters, commandType: CommandType.StoredProcedure, buffered: false, commandTimeout: 60000);

                using (StreamWriter writer = File.CreateText(savePath))
                {
                    var csv = new CsvWriter(writer);
                    csv.Configuration.RegisterClassMap<CalculatorEventLossCsvMapping>();
                    csv.WriteRecords(results.Select(x => new CalculatorEventLoss
                    {
                        EventSetId = header.EventSetId,
                        GeoId = x.t031_id,
                        PerilId = x.t010_id,
                        LobId = x.t015_id,
                        Simulation = x.event_year,
                        EventId = x.event_id,
                        EventDay = x.event_day,
                        LayerAttrition = (double)x.layer_attrition,
                        ReinstatementAttrition = (double)x.reinstatement_attrition,
                    }));
                }
            }
        }


        public async Task<IEnumerable<CalculatorEventSetHeader>> ExtractHeadersAsync(string ids)
        {
            var sql = $@"SELECT 
                es.t061_id as EventSetId 
                ,t061_reference as Description 
                ,e.t060_id as SourceVersionId
                ,es.t061_id as ModelId 
                ,es.t061_id as SourceId 
                ,t060_source_system as SourceSystem
                ,es.t062_id as SourceVersion 
                ,t061_simulation_count as SimulationCount
                ,t061_date_imported as CreatedDateUtc
                ,t061_create_user as CreatedBy
                ,t061_eventset_xml as AdditionalInfo
				,pp.t153_uid as PayoutUid
				,es.t062_id
                ,CONCAT(t061_eventset_database,'.',t061_eventset_db_owner,'.',t061_eventset_loss_table) as LossSource
				,CONCAT(t061_eventset_database,'.',t061_eventset_db_owner,'.',t061_eventset_table) as EventSource                
                FROM [dbo].[t061_event_set] es
                INNER JOIN [OPTISIMDB_Eventsets].[dbo].[t060_event_source] e 
                ON es.t060_id = e.t060_id               
				INNER JOIN [OPTISIMDB_Calc].[dbo].[t153_payout_part_result] ppr
				ON ppr.t061_id = es.t061_id
				INNER JOIN [OPTISIMDB_Calc].[dbo].[t153_payout_part] pp
				ON pp.t153_id = ppr.t153_id

                WHERE es.t061_id IN ({ids})
                order by t061_date_imported desc";

            using (var conn = new SqlConnection(_connectionString))
            {
                var headers = await conn.QueryAsync<CalculatorEventSetHeader>(sql);
                return headers;
            }
        }

    }
}
