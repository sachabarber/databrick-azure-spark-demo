﻿namespace Nephila.EventSetExtractor.Services.Models
{
    public abstract class EventLossBase
    {
        public int EventSetId { get; set; }
        public int GeoId { get; set; }
        public int PerilId { get; set; }
        public int LobId { get; set; }
        public int EventId { get; set; }
        public int Simulation { get; set; }
        public int EventDay { get; set; }
    }
}
