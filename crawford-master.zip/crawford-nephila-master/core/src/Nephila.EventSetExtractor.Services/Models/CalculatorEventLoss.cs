﻿namespace Nephila.EventSetExtractor.Services.Models
{
    public class CalculatorEventLoss : EventLossBase
    {
        public double LayerAttrition { get; set; }
        public double ReinstatementAttrition { get; set; }
    }
}
