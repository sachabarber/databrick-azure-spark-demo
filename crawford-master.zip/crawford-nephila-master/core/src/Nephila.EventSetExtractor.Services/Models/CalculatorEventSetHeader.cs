﻿using System;

namespace Nephila.EventSetExtractor.Services.Models
{
    public class CalculatorEventSetHeader
    {
        public int EventSetId { get; set; }
        public string Description { get; set; }
        public string Type { get; set; }
        public string SourceSystem { get; set; } //CALC
        public string SourceVersion { get; set; } //
        public int SourceVersionId { get; set; } //200
        public int ModelId { get; set; } //t151_id
        public int SourceId { get; set; } //t061_id
        public int SimulationCount { get; set; }
        public DateTime CreatedDateUtc { get; set; }
        public string CreatedBy { get; set; }
        public string AdditionalInfo { get; set; }
        public string LossSource { get; set; }
        public string EventSource { get; set; }
        public Guid PayoutUid { get; set; }
    }
}
