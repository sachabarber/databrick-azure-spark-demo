﻿using System;

namespace Nephila.EventSetExtractor.Services.Models
{
    public class CatraderEventSetHeader
    {
        public int EventSetId { get; set; }
        public string Description { get; set; }
        public string SourceSystem { get; set; }
        public string SourceVersion { get; set; }
        public string SourceVersionId { get; set; }
        public int ModelId { get; set; }
        public int SourceId { get; set; }
        public int SimulationCount { get; set; }
        public DateTime CreatedDateUtc { get; set; }
        public string CreatedBy { get; set; }
        public string AdditionalInfo { get; set; }
        public string LossSource { get; set; }
        public string EventSource { get; set; }
        public string EventFactorClassification { get; set; }
    }
}
