﻿namespace Nephila.EventSetExtractor.Services.Models
{
    public class CatraderEventLoss : EventLossBase
    {
        public double Loss { get; set; }
    }
}
