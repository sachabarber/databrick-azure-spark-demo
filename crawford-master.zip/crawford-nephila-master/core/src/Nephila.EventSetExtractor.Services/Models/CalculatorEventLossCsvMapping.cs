﻿using System;
using System.Collections.Generic;
using System.Text;
using CsvHelper.Configuration;

namespace Nephila.EventSetExtractor.Services.Models
{
    public class CalculatorEventLossCsvMapping : ClassMap<CalculatorEventLoss>
    {
        public CalculatorEventLossCsvMapping()
        {
            int index = 1;

            Map(x => x.EventSetId).Index(index++);
            Map(x => x.GeoId).Index(index++);
            Map(x => x.PerilId).Index(index++);
            Map(x => x.LobId).Index(index++);
            Map(x => x.Simulation).Index(index++);
            Map(x => x.EventId).Index(index++);
            Map(x => x.EventDay).Index(index++);
            Map(x => x.LayerAttrition).Index(index++);
            Map(x => x.ReinstatementAttrition).Index(index++);
        }
    }
}
