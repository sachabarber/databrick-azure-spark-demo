﻿using System;
using System.Collections.Generic;
using System.Text;
using CsvHelper.Configuration;

namespace Nephila.EventSetExtractor.Services.Models
{
    public class CatraderEventLossCsvMapping : ClassMap<CatraderEventLoss>
    {
        public CatraderEventLossCsvMapping()
        {
            int index = 1;

            Map(x => x.EventSetId).Index(index++);
            Map(x => x.GeoId).Index(index++);
            Map(x => x.PerilId).Index(index++);
            Map(x => x.LobId).Index(index++);
            Map(x => x.Simulation).Index(index++);
            Map(x => x.EventId).Index(index++);
            Map(x => x.EventDay).Index(index++);
            Map(x => x.Loss).Index(index++);
        }
    }
}
