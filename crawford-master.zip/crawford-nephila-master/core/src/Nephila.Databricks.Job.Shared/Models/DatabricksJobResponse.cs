﻿using System;

namespace Nephila.Databricks.Job.Shared.Models
{
    public class DatabricksJobResponse
    {
        public int Id { get; set; }
        public string ModelDocketUri { get; set; }
        public int JobId { get; set; }
        public string Status { get; set; }
        public string ExceptionDetails { get; set; }
        public int? RunId { get; set; }
        public string RequestedByUser { get; set; }
        public DateTime DateTimeAddedUtc { get; set; }
        public DateTime DateTimeLastUpdatedUtc { get; set; }
    }
}
