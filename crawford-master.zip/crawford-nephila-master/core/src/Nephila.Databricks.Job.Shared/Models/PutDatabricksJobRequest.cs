﻿using System;

namespace Nephila.Databricks.Job.Shared.Models
{
    public class PutDatabricksJobRequest
    {
        public string ModelDocketUid { get; set; }
        public string JobType { get; set; }
        public string RequestedByUser { get; set; }
    }
}
