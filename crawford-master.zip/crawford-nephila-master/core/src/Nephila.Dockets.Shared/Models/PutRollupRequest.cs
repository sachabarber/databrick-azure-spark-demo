﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Nephila.Dockets.Shared.Models
{
    public class PutRollupRequest
    {
        public IEnumerable<RollupItem> RollupItems { get; set; }
        public string RequestedByUser { get; set; }
    }
}
