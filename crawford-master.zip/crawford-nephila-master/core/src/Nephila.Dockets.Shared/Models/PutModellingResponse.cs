﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Nephila.Dockets.Shared.Models
{
    public class PutModellingResponse
    {
        public Guid Id { get; set; }
        public string DocumentUri { get; set; }
        public string ETag { get; set; }
    }
}
