﻿using Newtonsoft.Json;

namespace Nephila.Dockets.Shared.Models
{
    public class SummaryStats
    {
        [JsonProperty(PropertyName = "metric")]
        public string Metric { get; set; }

        [JsonProperty(PropertyName = "desc")]
        public string Desc { get; set; }

        public double Simulation { get; set; }
        public double SumFactorLoss { get; set; }
        public double MaxFactorLoss { get; set; }
    }
}
