﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Nephila.Dockets.Shared.Models
{
    public class CatraderEventSetDocket : EventSetDocket
    {
        public override string EngineName => "CatraderImport";
        public string SourceVersion { get; set; }
        public int SimulationCount { get; set; }
        public string LossSource { get; set; }
        public string EventFactorClassification { get; set; }
        public string AdditionalInfo { get; set; }
    }
}
