﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Nephila.Dockets.Shared.Models
{
    public class PutRollupResponse
    {
        public Guid Id { get; set; }
        public string ETag { get; set; }
    }
}
