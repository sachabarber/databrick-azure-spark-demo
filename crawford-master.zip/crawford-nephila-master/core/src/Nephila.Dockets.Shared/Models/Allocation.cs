﻿namespace Nephila.Dockets.Shared.Models
{
    public class Allocation
    {
        public string Name { get; set; }
        public decimal AllocationPercentage { get; set; }
    }
}