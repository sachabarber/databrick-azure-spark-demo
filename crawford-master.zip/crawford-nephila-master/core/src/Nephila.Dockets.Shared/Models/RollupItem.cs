﻿using System.Collections.Generic;

namespace Nephila.Dockets.Shared.Models
{
    public class RollupItem
    {
        public string EventSetSource { get; set; }
        public int EventSetId { get; set; }
        public double Limit { get; set; }
        public IEnumerable<Allocation> Allocations { get; set; }
    }
}