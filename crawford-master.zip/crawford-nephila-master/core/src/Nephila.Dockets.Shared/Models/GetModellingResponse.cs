﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Nephila.Dockets.Shared.Models
{
    public class GetModellingResponse
    {
        public Guid Id { get; set; }
        public double Limit { get; set; }
        public double Excess { get; set; }
        public string TriggerType { get; set; }
        public int EventSetId { get; set; }
        public string EventSetSource { get; set; }
        public string RequestedByUser { get; set; }
    }
}
