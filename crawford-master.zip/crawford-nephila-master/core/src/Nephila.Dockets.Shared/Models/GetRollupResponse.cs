﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Nephila.Dockets.Shared.Models
{
    public class GetRollupResponse
    {
        public Guid Id { get; set; }
        public IEnumerable<RollupItem> RollupItems { get; set; }
        public string RequestedByUser { get; set; }
    }
}
