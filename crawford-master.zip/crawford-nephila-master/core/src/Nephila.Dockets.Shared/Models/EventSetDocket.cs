﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace Nephila.Dockets.Shared.Models
{
    public abstract class EventSetDocket
    {
        [JsonProperty(PropertyName = "id")]
        public string Id { get; set; }
        public abstract string EngineName { get; }
        public string EngineVersion { get; set; }
        public string ModelId { get; set; }
        public string ResultId { get; set; }
        public string Description { get; set; }
        public string Comments { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedDateUtc { get; set; }
    }
}
