﻿using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;
using System;
using System.Collections.Generic;

namespace Nephila.Databricks.WebApi.Migrations
{
    public partial class InitialMigration : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "DatabricksJobs",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    DateTimeAddedUtc = table.Column<DateTime>(nullable: false),
                    DateTimeLastUpdatedUtc = table.Column<DateTime>(nullable: false),
                    ExceptionDetails = table.Column<string>(nullable: true),
                    JobType = table.Column<string>(maxLength: 50, nullable: false),
                    RequestedByUser = table.Column<string>(nullable: true),
                    Status = table.Column<string>(maxLength: 50, nullable: false),
                    JobParameters = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_DatabricksJobs", x => x.Id);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "DatabricksJobs");
        }
    }
}
