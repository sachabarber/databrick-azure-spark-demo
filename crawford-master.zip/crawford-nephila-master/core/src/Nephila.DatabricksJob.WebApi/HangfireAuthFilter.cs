﻿using Hangfire.Dashboard;
using Microsoft.AspNetCore.Mvc.Filters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Hangfire.Annotations;
using Microsoft.AspNetCore.Authentication;

namespace Nephila.Databricks.WebApi
{
    public class HangfireAuthFilter : IDashboardAuthorizationFilter
    {
        public bool Authorize(DashboardContext context)
        {
            return true;
            //var token = Task.Run(context.GetHttpContext().GetTokenAsync()
        }        
    }
}
