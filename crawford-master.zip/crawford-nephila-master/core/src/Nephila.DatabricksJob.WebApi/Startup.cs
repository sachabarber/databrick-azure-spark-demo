﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Hangfire;
using Nephila.Databricks.WebApi.Models;
using Nephila.Databricks.WebApi.Services;
using Microsoft.EntityFrameworkCore;
using AutoMapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.IdentityModel.Tokens;
using System.Text;
using Swashbuckle.AspNetCore.Swagger;
using Swashbuckle.AspNetCore.Examples;
using Hangfire.SqlServer;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication.OpenIdConnect;
using Microsoft.AspNetCore.Authentication;
using Microsoft.IdentityModel.Protocols.OpenIdConnect;
using Hangfire.Dashboard;
using Microsoft.AspNetCore.Http;

namespace Nephila.Databricks.WebApi
{
    public class Startup
    {
        private IHostingEnvironment _env;
        private readonly IConfigurationRoot _config;
        private readonly string _jobDbConnectionString;

        public Startup(IHostingEnvironment env)
        {
            var builder = new ConfigurationBuilder()
                .SetBasePath(env.ContentRootPath)
                .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true)
                .AddJsonFile($"appsettings.{env.EnvironmentName}.json", optional: true)
                .AddEnvironmentVariables();
            _env = env;
            _config = builder.Build();
            _jobDbConnectionString = _config["JobDb:ConnectionString"];
        }

        public IConfiguration Configuration { get; }

        public void ConfigureServices(IServiceCollection services)
        {
            services.AddSingleton(_config);
            services.AddScoped<IDatabricksRunPollingSvc, DatabricksRunPollingSvc>();
            services.AddScoped<IDatabricksWebApiClient, DatabricksWebApiClient>();
            services.AddScoped<IJobTopicPublisher, JobTopicPublisher>();
            services.AddScoped<IDatabricksJobRunner, DatabricksJobRunner>();
            services.AddScoped<IDatabricksJobRepository, DatabricksJobRepository>();
            services.AddScoped<IDatabricksJobStatusHandler, DatabricksJobStatusHandler>();
            services.AddScoped<IDatabricksJobIdMapper, DatabricksJobIdMapper>();
            services.AddDbContext<JobDbContext>(x => x.UseSqlServer(_jobDbConnectionString));
            services.AddLogging();

            var sp = services.BuildServiceProvider();


            var sqlOptions = new SqlServerStorageOptions
            {
                QueuePollInterval = TimeSpan.FromSeconds(1)
            };
            services.AddHangfire(x => x.UseSqlServerStorage(_jobDbConnectionString, sqlOptions));

            services.AddAutoMapper();

            services.AddAuthentication(o =>
            {
                o.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
                o.DefaultScheme = JwtBearerDefaults.AuthenticationScheme;
                o.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
            })
            //.AddOpenIdConnect(o =>
            //{
            //    _config.Bind("AzureAd", o);
            //    o.ResponseType = OpenIdConnectResponseType.IdToken;
            //    o.SaveTokens = true;
            //    o.Events = new OpenIdConnectEvents
            //    {
            //        //OnRemoteFailure = RemoteFailure,
            //        //OnTokenValidated = TokenValidated
            //    };
            //    //options.TokenValidationParameters = new TokenValidationParameters
            //    //{
            //    //    // Instead of using the default validation (validating against
            //    //    // a single issuer value, as we do in line of business apps), 
            //    //    // we inject our own multitenant validation logic
            //    //    ValidateIssuer = false,

            //    //    NameClaimType = "name"
            //    //};
            //})            
            .AddJwtBearer(o =>
            {
                _config.Bind("AzureAd", o);
                o.Events = new JwtBearerEvents
                {
                    OnAuthenticationFailed = AuthFailed,
                    OnTokenValidated = TokenValidated
                };
                o.TokenValidationParameters = new TokenValidationParameters
                {
                    ValidAudiences = new List<string> {
                        "https://burnsjpgmail.onmicrosoft.com/c2940ba9-5cd5-4b9f-8376-63b4bc86c511",
                        "d1f920e0-79d4-42b0-9b95-4b530f02351a" },
                };
            });

            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new Info { Title = "Jobs API", Version = "v1" });
                c.AddSecurityDefinition("Bearer", new ApiKeyScheme
                {
                    Description = "JWT Authorization header using the Bearer scheme. Example: \"Authorization: Bearer {token}\"",
                    Name = "Authorization",
                    In = "header",
                    Type = "apiKey"
                });
                c.OperationFilter<ExamplesOperationFilter>();
            });
            services.AddMvc();
        }

        private Task TokenValidated(Microsoft.AspNetCore.Authentication.JwtBearer.TokenValidatedContext arg)
        {

            return Task.FromResult(0);
        }

        private Task AuthFailed(Microsoft.AspNetCore.Authentication.JwtBearer.AuthenticationFailedContext arg)
        {
            return Task.FromResult(0);
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseSwagger();
            app.UseAuthentication();
            GlobalJobFilters.Filters.Add(new AutomaticRetryAttribute { Attempts = 0 });
            app.UseHangfireServer();
            app.UseHangfireDashboard("/hangfire", new DashboardOptions
            {
                Authorization = new[] { new HangfireAuthFilter() }
            });
            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint("/swagger/v1/swagger.json", "Dockets API V1");
            });

            app.UseMvc();
        }

        private static IApplicationBuilder UseHangfireDashboardCustom(IApplicationBuilder app, string pathMatch = "/hangfire", DashboardOptions options = null, JobStorage storage = null)
        {
            var services = app.ApplicationServices;
            storage = storage ?? services.GetRequiredService<JobStorage>();
            options = options ?? services.GetService<DashboardOptions>() ?? new DashboardOptions();
            var routes = app.ApplicationServices.GetRequiredService<RouteCollection>();

            app.Map(new PathString(pathMatch), x =>
                x.UseMiddleware<HangfireDashboardMiddleware>(storage, options, routes));

            return app;
        }
    }
}
