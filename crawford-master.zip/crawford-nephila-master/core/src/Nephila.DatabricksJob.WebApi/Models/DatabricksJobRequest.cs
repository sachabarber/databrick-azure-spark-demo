﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace Nephila.Databricks.WebApi.Models
{
    public class DatabricksJobRequest
    {
        [JsonProperty(PropertyName = "run_name")]
        public string RunName { get; set; }

        [JsonProperty(PropertyName = "existing_cluster_id")]
        public string ExistingClusterId { get; set; }

        [JsonProperty(PropertyName = "notebook_task")]
        public NotebookTask Task { get; set; }

        [JsonProperty(PropertyName = "timeout_seconds")]
        public int TimeoutSeconds { get; set; }

        [JsonProperty(PropertyName = "email_notifications")]
        public EmailNotifications Notifications { get; set; }

        public class NotebookTask
        {
            [JsonProperty(PropertyName = "notebook_path")]
            public string NotebookPath { get; set; }
        }

        public class EmailNotifications
        {
            [JsonProperty(PropertyName = "on_start")]
            public List<string> OnStart { get; set; }

            [JsonProperty(PropertyName = "on_success")]
            public List<string> OnSuccess { get; set; }

            [JsonProperty(PropertyName = "on_failure")]
            public List<string> OnFailure { get; set; }
        }
    }
}
