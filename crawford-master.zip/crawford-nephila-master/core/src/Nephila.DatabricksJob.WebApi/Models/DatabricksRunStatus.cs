﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Nephila.Databricks.WebApi.Models
{
    public enum DatabricksRunStatus
    {
        Running = 1,
        Success = 2,
    }
}
