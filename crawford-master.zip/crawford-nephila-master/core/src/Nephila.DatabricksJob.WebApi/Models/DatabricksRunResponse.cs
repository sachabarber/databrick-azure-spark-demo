﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace Nephila.Databricks.WebApi.Models
{
    public class DatabricksRunResponse
    {
        [JsonProperty(PropertyName = "job_id")]
        public int JobId { get; set; }

        [JsonProperty(PropertyName = "run_id")]
        public int RunId { get; set; }

        [JsonProperty(PropertyName = "state")]
        public DatabricksRunState RunState { get; set; }


        public class DatabricksRunState
        {
            [JsonProperty(PropertyName = "life_cycle_state")]
            public string LifecycleState { get; set; }

            [JsonProperty(PropertyName = "result_state")]
            public string ResultState { get; set; }

            [JsonProperty(PropertyName = "state_message")]
            public string StateMessage { get; set; }
        }

        public DatabricksRunResponse()
        { 
        }
    }
}
