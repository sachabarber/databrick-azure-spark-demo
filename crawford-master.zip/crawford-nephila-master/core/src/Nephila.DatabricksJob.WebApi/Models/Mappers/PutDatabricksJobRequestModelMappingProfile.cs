﻿using AutoMapper;
using Nephila.Databricks.Job.Shared.Models;
using Nephila.Databricks.WebApi.Entities;
using Nephila.Databricks.WebApi.Models.Messages;
using Nephila.Databricks.WebApi.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Nephila.Databricks.WebApi.Models.Mappers
{
    public class PutDatabricksJobRequestModelMappingProfile : Profile
    {
        private readonly IDatabricksJobIdMapper _jobIdMapper;

        public PutDatabricksJobRequestModelMappingProfile()
        {
            _jobIdMapper = new DatabricksJobIdMapper();

            CreateMap<PutDatabricksJobRequest, DatabricksJob>()
                .ConvertUsing(DatabricksCrawfordJobConverter);
        }

        private DatabricksJob DatabricksCrawfordJobConverter(PutDatabricksJobRequest arg)
        {
            var job = new Entities.DatabricksJob
            { 
                RequestedByUser = arg.RequestedByUser,
                JobType = arg.JobType,
                JobParameters = new DatabricksRunRequest
                {
                    JobId = _jobIdMapper.MapJobId(arg.JobType),
                    RunParams = new DatabricksRunRequest.NotebookRunParams
                    {
                        ModellingDocketUri = arg.ModelDocketUid.ToString()
                    }
                },
            };

            return job;
        }
    }
}
