﻿using AutoMapper;
using Nephila.Databricks.Job.Shared.Models;
using Nephila.Databricks.WebApi.Entities;
using Nephila.Databricks.WebApi.Models.Messages;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Nephila.Databricks.WebApi.Models.Mappers
{
    public class DatabricksJobResponseModelMappingProfile : Profile
    {
        public DatabricksJobResponseModelMappingProfile()
        {
            CreateMap<DatabricksJob, DatabricksJobResponse>().ConvertUsing(DatabricksJobConverter);
        }

        private DatabricksJobResponse DatabricksJobConverter(Entities.DatabricksJob arg)
        {
            var response = new DatabricksJobResponse
            {
                Id = arg.Id,
                ExceptionDetails = arg.ExceptionDetails,
                JobId = arg.JobParameters.JobId,
                RequestedByUser = arg.RequestedByUser,
                RunId = arg.JobParameters.RunId,
                ModelDocketUri = arg.JobParameters.RunParams.ModellingDocketUri,
                Status = arg.Status,
                DateTimeAddedUtc = arg.DateTimeAddedUtc,
                DateTimeLastUpdatedUtc = arg.DateTimeLastUpdatedUtc,
            };

            return response;
        }
    }
}
