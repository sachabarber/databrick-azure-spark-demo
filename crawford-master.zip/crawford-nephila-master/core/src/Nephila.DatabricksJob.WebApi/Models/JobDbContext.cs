﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Nephila.Databricks.WebApi.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace Nephila.Databricks.WebApi.Models
{
    public class JobDbContext : DbContext
    {
        private readonly string _connectionString;
        public DbSet<Entities.DatabricksJob> DatabricksJobs { get; set; }
        
        public JobDbContext(DbContextOptions options, string connectionString) : base(options)
        {
            _connectionString = connectionString;
        }

        public JobDbContext(DbContextOptions options, IConfigurationRoot config) : base(options)
        {
            _connectionString = config["JobDb:ConnectionString"];
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            base.OnConfiguring(optionsBuilder);

            optionsBuilder.UseSqlServer(_connectionString);
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<DatabricksJob>()
                .Property(b => b._JobParameters)
                .HasColumnName("JobParameters");   
        }
    }
}
