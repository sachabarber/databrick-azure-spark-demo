﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Nephila.Databricks.WebApi.Models
{
    public class AwsAttributes
    {
        public string zone_id { get; set; }
        public int first_on_demand { get; set; }
        public string availability { get; set; }
        public int spot_bid_price_percent { get; set; }
        public string ebs_volume_type { get; set; }
        public int ebs_volume_count { get; set; }
        public int ebs_volume_size { get; set; }
    }

    public class DefaultTags
    {
        public string Vendor { get; set; }
        public string Creator { get; set; }
        public string ClusterName { get; set; }
        public string ClusterId { get; set; }
    }

    public class Parameters
    {
        public string inactivity_duration_min { get; set; }
    }

    public class TerminationReason
    {
        public string code { get; set; }
        public Parameters parameters { get; set; }
    }

    public class DatabricksClusterResponseAws
    {
        public string cluster_id { get; set; }
        public long spark_context_id { get; set; }
        public string cluster_name { get; set; }
        public string spark_version { get; set; }
        public AwsAttributes aws_attributes { get; set; }
        public string node_type_id { get; set; }
        public string driver_node_type_id { get; set; }
        public int autotermination_minutes { get; set; }
        public bool enable_elastic_disk { get; set; }
        public string cluster_source { get; set; }
        public bool enable_jdbc_auto_start { get; set; }
        public string state { get; set; }
        public string state_message { get; set; }
        public long start_time { get; set; }
        public long terminated_time { get; set; }
        public long last_state_loss_time { get; set; }
        public long last_activity_time { get; set; }
        public int num_workers { get; set; }
        public int cluster_memory_mb { get; set; }
        public double cluster_cores { get; set; }
        public DefaultTags default_tags { get; set; }
        public string creator_user_name { get; set; }
        public TerminationReason termination_reason { get; set; }
    }
}
