﻿using Swashbuckle.AspNetCore.Examples;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Nephila.Databricks.WebApi.Models.Examples
{
    public class DatabricksClusterRequestExample : IExamplesProvider
    {
        public object GetExamples()
        {
            return "0106-160506-alley724";
        }
    }
}
