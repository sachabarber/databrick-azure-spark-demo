﻿using Nephila.Databricks.Job.Shared.Models;
using Nephila.Databricks.WebApi.Entities;
using Nephila.Databricks.WebApi.Models.Messages;
using Swashbuckle.AspNetCore.Examples;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Nephila.Databricks.WebApi.Models.Examples
{
    public class PutDatabricksJobRequestExample : IExamplesProvider
    {
        public object GetExamples()
        {
            return new PutDatabricksJobRequest
            {
                ModelDocketUid = "6063d3bc-4313-46b9-b5c2-be9a5c464952",
                RequestedByUser = "jburns",
                JobType = "CRAWFORD",
            };
        }
    }
}
