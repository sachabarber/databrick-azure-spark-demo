﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Nephila.Databricks.WebApi.Models.Messages
{
    public class DatabricksJobStatusMsg
    {
        public DatabricksRunResponse DatabricksRunResponse { get; set; }
        public string ModellingDocketPath { get; set; }
        public string RequestedByUser { get; set; }
        public DateTime RequestedDatetimeUtc { get; set; }
        public Guid RequestUid { get; set; }

        public DatabricksJobStatusMsg()
        {
            DatabricksRunResponse = new DatabricksRunResponse();
        }
    }
}
