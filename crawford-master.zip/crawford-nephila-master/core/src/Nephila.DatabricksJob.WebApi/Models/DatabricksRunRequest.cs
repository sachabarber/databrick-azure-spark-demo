﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace Nephila.Databricks.WebApi.Models
{
    public class DatabricksRunRequest
    {
        [JsonProperty(PropertyName = "job_id")]
        public int JobId { get; set; }

        [JsonProperty(PropertyName = "notebook_params")]
        public NotebookRunParams RunParams { get; set; }

        [JsonProperty(PropertyName = "run_id")]
        public int? RunId { get; set; }

        public class NotebookRunParams
        {
            [JsonProperty(PropertyName = "modelling_docket_uri")]
            public string ModellingDocketUri { get; set; }
        }

        public DatabricksRunRequest()
        {
            RunParams = new NotebookRunParams();
        }
    }
}
