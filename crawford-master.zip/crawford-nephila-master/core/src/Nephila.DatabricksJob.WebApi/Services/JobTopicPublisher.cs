﻿using Microsoft.Azure.ServiceBus;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Nephila.Databricks.WebApi.Services
{
    public class JobTopicPublisher : IJobTopicPublisher
    {
        private readonly IConfigurationRoot _config;
        private readonly string _jobBusConnectionString;
        private readonly string _topicName;
        private readonly ITopicClient _topicClient;

        public JobTopicPublisher(IConfigurationRoot config)
        {
            _config = config;
            _jobBusConnectionString = config["JobBus:ConnectionString"];
            _topicName = config["JobBus:ModellingStatusTopicName"];

            _topicClient = new TopicClient(_jobBusConnectionString, _topicName);
        }

        public async Task PublishJobRunStatus<T>(T statusMessage)
        {
            string messageBody = JsonConvert.SerializeObject(statusMessage);
            var message = new Message(Encoding.UTF8.GetBytes(messageBody))
            {
                SessionId = Guid.NewGuid().ToString()
            };
            await _topicClient.SendAsync(message);
        }
    }
}
