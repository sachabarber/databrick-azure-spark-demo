﻿using System.Threading.Tasks;
using Polly;
using Nephila.Databricks.WebApi.Entities;
using Nephila.Databricks.WebApi.Models;

namespace Nephila.Databricks.WebApi.Services
{
    public interface IDatabricksJobStatusHandler
    {
        Task OnRunExceptionAsync(PolicyResult<DatabricksRunResponse> policyResult, Entities.DatabricksJob job);
        Task OnRunFailedAsync(DatabricksRunResponse databricksRunResponse, Entities.DatabricksJob job);
        Task OnRunFinishedAsync(DatabricksRunResponse databricksRunResponse, Entities.DatabricksJob job);
        Task OnRunStartedAsync(Entities.DatabricksJob job);
        Task OnRunSuccessAsync(DatabricksRunResponse databricksRunResponse, Entities.DatabricksJob job);
    }
}