﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Nephila.Databricks.WebApi.Services
{
    public class DatabricksJobIdMapper : IDatabricksJobIdMapper
    {
        private Dictionary<string, int> _jobIdMappings = new Dictionary<string, int>
            {
                { "CRAWFORD", 1 },
                { "ROLLUP", 1 },
            };
        

        public int MapJobId(string jobType)
        {
            return _jobIdMappings[jobType.ToUpper()];
        }
    }
}
