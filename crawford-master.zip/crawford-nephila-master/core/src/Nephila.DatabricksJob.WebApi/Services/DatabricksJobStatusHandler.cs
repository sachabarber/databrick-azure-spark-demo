﻿using Microsoft.Extensions.Configuration;
using Nephila.Databricks.WebApi.Services;
using Nephila.Databricks.WebApi.Entities;
using Nephila.Databricks.WebApi.Exceptions;
using Nephila.Databricks.WebApi.Models;
using Nephila.Databricks.WebApi.Models.Messages;
using Polly;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Nephila.Databricks.WebApi.Services
{
    public class DatabricksJobStatusHandler : IDatabricksJobStatusHandler
    {
        private readonly IConfigurationRoot _config;
        private readonly IDatabricksJobRepository _jobRepository;
        private readonly IJobTopicPublisher _jobTopicPublisher;

        public DatabricksJobStatusHandler(IConfigurationRoot config,
            IDatabricksJobRepository jobRepository,
            IJobTopicPublisher jobTopicPublisher)
        {
            _config = config;
            _jobRepository = jobRepository;
            _jobTopicPublisher = jobTopicPublisher;
        }

        public async Task OnRunStartedAsync(Entities.DatabricksJob job)
        {
            job.Status = "STARTED";
            await _jobRepository.UpdateAsync(job);
        }

        public async Task OnRunFinishedAsync(DatabricksRunResponse databricksRunResponse, Entities.DatabricksJob job)
        {
            if (databricksRunResponse.RunState.ResultState == "SUCCESS")
            {
                await OnRunSuccessAsync(databricksRunResponse, job);
            }
            else
            {
                await OnRunFailedAsync(databricksRunResponse, job);
            }
        }

        public async Task OnRunSuccessAsync(DatabricksRunResponse databricksRunResponse, Entities.DatabricksJob job)
        {
            job.Status = "SUCCESS";
            await PublishStatusMessageAsync(databricksRunResponse, job);
        }

        public async Task OnRunFailedAsync(DatabricksRunResponse databricksRunResponse, Entities.DatabricksJob job)
        {
            job.Status = "FAILED";
            var failMessage = $"Run failed for run_id {databricksRunResponse.RunId}, job_id { databricksRunResponse.JobId}. " +
                $"Lifecycle state: {databricksRunResponse.RunState.LifecycleState}, " +
                $"Message: {databricksRunResponse.RunState.StateMessage}, Result state: {databricksRunResponse.RunState.ResultState}";
            job.ExceptionDetails = failMessage;

            await PublishStatusMessageAsync(databricksRunResponse, job);
            throw new DatabricksJobException(failMessage);
        }

        public async Task OnRunExceptionAsync(PolicyResult<DatabricksRunResponse> policyResult, Entities.DatabricksJob job)
        {
            job.ExceptionDetails = policyResult.FinalException.Message;
            job.Status = "FAILED";
            await PublishStatusMessageAsync(policyResult.Result, job);
            throw new DatabricksJobException($"Run exception", policyResult.FinalException);
        }

        private async Task PublishStatusMessageAsync(DatabricksRunResponse databricksRunResponse, Entities.DatabricksJob job)
        {
            await _jobRepository.UpdateAsync(job);
            var statusMessage = new DatabricksJobStatusMsg
            {
                DatabricksRunResponse = databricksRunResponse,
                RequestedByUser = job.RequestedByUser,
                RequestedDatetimeUtc = job.DateTimeAddedUtc,
                //RequestUid = job.RequestUid,
            };

            await _jobTopicPublisher.PublishJobRunStatus(statusMessage);
        }
    }
}
