﻿using Hangfire;
using Microsoft.Extensions.Configuration;
using Nephila.Databricks.WebApi.Entities;
using Nephila.Databricks.WebApi.Models;
using Polly;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace Nephila.Databricks.WebApi.Services
{
    public class DatabricksRunPollingSvc : IDatabricksRunPollingSvc
    {
        private readonly IConfigurationRoot _config;
        private readonly IDatabricksWebApiClient _databricksWebApiClient;
        private readonly IDatabricksJobStatusHandler _jobStatusHandler;
        private readonly TimeSpan _pollingTimeSeconds;

        public DatabricksRunPollingSvc(IConfigurationRoot config,
            IDatabricksWebApiClient databricksWebApiClient,
            IDatabricksJobStatusHandler jobStatusHandler)
        {
            _config = config;
            _databricksWebApiClient = databricksWebApiClient;
            _jobStatusHandler = jobStatusHandler;
            _pollingTimeSeconds = TimeSpan.FromSeconds(int.Parse(_config["Databricks:RunPollingSeconds"]));
        }

        public async Task StartPollingAsync(Entities.DatabricksJob job, IJobCancellationToken cancellationToken)
        {
            var statusesToRetry = new List<string> { "PENDING", "RUNNING" };

            await _jobStatusHandler.OnRunStartedAsync(job);

            var policyResult = await Policy.HandleResult<DatabricksRunResponse>(x =>
            {
                cancellationToken.ThrowIfCancellationRequested();
                
                return statusesToRetry.Contains(x.RunState.LifecycleState);
            })
                .WaitAndRetryForeverAsync(retryAttempt => _pollingTimeSeconds)
                .ExecuteAndCaptureAsync(() => PollAsync(job));

            if (policyResult.Outcome == OutcomeType.Failure)
            {
                await _jobStatusHandler.OnRunExceptionAsync(policyResult, job);
            }

            await _jobStatusHandler.OnRunFinishedAsync(policyResult.Result, job);
        }

        private async Task<DatabricksRunResponse> PollAsync(Entities.DatabricksJob job)
        {
            var runStatus = await _databricksWebApiClient.GetRunStatusAsync(job.JobParameters.RunId.Value);
            return runStatus;
        }
    }
}
