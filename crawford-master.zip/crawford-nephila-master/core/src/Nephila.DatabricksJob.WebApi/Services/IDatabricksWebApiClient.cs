﻿using Nephila.Databricks.WebApi.Models;
using System;
using System.Threading.Tasks;

namespace Nephila.Databricks.WebApi.Services
{
    public interface IDatabricksWebApiClient
    {
        Task<DatabricksRunResponse> GetRunStatusAsync(int runId);
        Task<int> StartRunAsync(DatabricksRunRequest runRequest);
        Task<int> SubmitJobAsync(string jsonJobRequest);
        Task<DatabricksClusterResponseAws> StartClusterAsync(string clusterId);
        Task<DatabricksClusterResponseAws> GetClusterStatusAsync(string clusterId);
    }
}