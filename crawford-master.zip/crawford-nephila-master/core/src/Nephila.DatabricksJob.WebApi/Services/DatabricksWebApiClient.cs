﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using RestSharp;
using Newtonsoft.Json.Linq;
using RestSharp.Serializers.Newtonsoft.Json;
using Nephila.Databricks.WebApi.Models;

namespace Nephila.Databricks.WebApi.Services
{
    public class DatabricksWebApiClient : IDatabricksWebApiClient
    {
        private readonly IConfigurationRoot _configuration;
        private readonly string _url;
        private readonly string _username;
        private readonly string _token;
        private readonly string _authHeader;
        private readonly RestClient _client;

        public DatabricksWebApiClient(IConfigurationRoot configuration)
        {
            _configuration = configuration;
            _url = configuration["Databricks:Url"];
            _username = configuration["Databricks:Username"];
            _token = configuration["Databricks:Token"];

            var authHeaderBytes = System.Text.Encoding.UTF8.GetBytes($"{_username}:{_token}");
            _authHeader = System.Convert.ToBase64String(authHeaderBytes);

            _client = new RestClient(_url);
        }

        public async Task<int> SubmitJobAsync(string jsonJobRequest)
        {
            var request = new RestSharp.Serializers.Newtonsoft.Json.RestRequest("api/2.0/jobs/create", Method.POST);
            request.AddHeader("Authorization", $"Basic {_authHeader}");
            request.AddParameter("application/json", jsonJobRequest, ParameterType.RequestBody);

            var response = await _client.ExecuteTaskAsync(request);
            dynamic responseContent = JObject.Parse(response.Content);
            var jobId = responseContent.job_id;
            return jobId;
        }

        public async Task<int> StartRunAsync(DatabricksRunRequest runRequest)
        {
            var request = new RestSharp.Serializers.Newtonsoft.Json.RestRequest("api/2.0/jobs/run-now", Method.POST);
            request.AddHeader("Authorization", $"Basic {_authHeader}");
            request.AddJsonBody(runRequest);

            var response = await _client.ExecuteTaskAsync(request);
            dynamic responseContent = JObject.Parse(response.Content);
            var runId = responseContent.run_id;
            return runId;
        }

        public async Task<DatabricksRunResponse> GetRunStatusAsync(int runId)
        {
            var request = new RestSharp.Serializers.Newtonsoft.Json.RestRequest("api/2.0/jobs/runs/get", Method.GET);
            request.AddHeader("Authorization", $"Basic {_authHeader}");
            request.AddQueryParameter("run_id", runId.ToString());

            var response = await _client.ExecuteTaskAsync<DatabricksRunResponse>(request);

            var dbResponse = JsonConvert.DeserializeObject<DatabricksRunResponse>(response.Content);

            return dbResponse;
        }

        public async Task<DatabricksClusterResponseAws> StartClusterAsync(string clusterId)
        {
            var request = new RestSharp.Serializers.Newtonsoft.Json.RestRequest("api/2.0/clusters/start", Method.POST);
            request.AddHeader("Authorization", $"Basic {_authHeader}");
            request.AddJsonBody(new { cluster_id = clusterId });

            var response = await _client.ExecuteTaskAsync<DatabricksClusterResponseAws>(request);

            var dbResponse = JsonConvert.DeserializeObject<DatabricksClusterResponseAws>(response.Content);

            return dbResponse;
        }

        public async Task<DatabricksClusterResponseAws> GetClusterStatusAsync(string clusterId)
        {
            var request = new RestSharp.Serializers.Newtonsoft.Json.RestRequest("api/2.0/clusters/get", Method.GET);
            request.AddHeader("Authorization", $"Basic {_authHeader}");
            request.AddQueryParameter("cluster_id", clusterId);

            var response = await _client.ExecuteTaskAsync<DatabricksClusterResponseAws>(request);

            var dbResponse = JsonConvert.DeserializeObject<DatabricksClusterResponseAws>(response.Content);

            return dbResponse;
        }
    }
}
