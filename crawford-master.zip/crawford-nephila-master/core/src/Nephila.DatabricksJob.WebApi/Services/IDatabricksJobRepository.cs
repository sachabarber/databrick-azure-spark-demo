﻿using Nephila.Databricks.WebApi.Entities;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Nephila.Databricks.WebApi.Services
{
    public interface IDatabricksJobRepository
    {
        Task<IEnumerable<DatabricksJob>> GetAllAsync();
        Task<DatabricksJob> GetAsync(int id);
        Task<DatabricksJob> InsertAsync(DatabricksJob job);
        Task<DatabricksJob> UpdateAsync(DatabricksJob job);
    }
}