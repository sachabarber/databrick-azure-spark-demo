﻿namespace Nephila.Databricks.WebApi.Services
{
    public interface IDatabricksJobIdMapper
    {
        int MapJobId(string jobType);
    }
}