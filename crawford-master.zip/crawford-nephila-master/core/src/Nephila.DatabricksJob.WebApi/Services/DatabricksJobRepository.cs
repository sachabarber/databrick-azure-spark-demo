﻿using Microsoft.EntityFrameworkCore;
using Nephila.Databricks.WebApi.Entities;
using Nephila.Databricks.WebApi.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Nephila.Databricks.WebApi.Services
{
    public class DatabricksJobRepository : IDatabricksJobRepository
    {
        protected readonly JobDbContext _ctx;

        public DatabricksJobRepository(JobDbContext ctx)
        {
            _ctx = ctx;
        }

        public async Task<DatabricksJob> GetAsync(int id)
        {
            return await _ctx.DatabricksJobs.SingleOrDefaultAsync(x => x.Id == id);
        }

        public async Task<DatabricksJob> InsertAsync(DatabricksJob job)
        {
            job.Status = "QUEUED";

            job.DateTimeAddedUtc = DateTime.UtcNow;
            job.DateTimeLastUpdatedUtc = job.DateTimeAddedUtc;
            _ctx.DatabricksJobs.Add(job);
            await _ctx.SaveChangesAsync();
            return job;
        }

        public async Task<DatabricksJob> UpdateAsync(DatabricksJob job)
        {
            job.DateTimeLastUpdatedUtc = DateTime.UtcNow;
            _ctx.DatabricksJobs.Update(job);
            await _ctx.SaveChangesAsync();
            return job;
        }

        public async Task<IEnumerable<DatabricksJob>> GetAllAsync()
        {
            return await _ctx.DatabricksJobs.AsNoTracking().ToListAsync();
        }
    }
}
