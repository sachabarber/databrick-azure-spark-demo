﻿using Hangfire;
using Nephila.Databricks.WebApi.Entities;
using System.Threading;
using System.Threading.Tasks;

namespace Nephila.Databricks.WebApi.Services
{
    public interface IDatabricksRunPollingSvc
    {
        Task StartPollingAsync(Entities.DatabricksJob job, IJobCancellationToken cancellationToken);
    }
}