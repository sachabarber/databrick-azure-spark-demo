﻿using System.Threading.Tasks;
using Hangfire.Server;

namespace Nephila.Databricks.WebApi.Services
{
    public interface IDatabricksJobRunner
    {
        Task Run(int jobId, PerformContext context);
    }
}