﻿using System.Threading.Tasks;

namespace Nephila.Databricks.WebApi.Services
{
    public interface IJobTopicPublisher
    {
        Task PublishJobRunStatus<T>(T statusMessage);
    }
}