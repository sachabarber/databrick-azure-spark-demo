﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Nephila.Databricks.WebApi.Services
{
    public class JobDbInitializer
    {
        //public async Task SeedAsync()
        //{
        //    var user = await _userMgr.FindByNameAsync("nephila");

        //    // Add User
        //    if (user == null)
        //    {
        //        if (!(await _roleMgr.RoleExistsAsync("Admin")))
        //        {
        //            var role = new IdentityRole("Admin");
        //            await _roleMgr.CreateAsync(role);
        //            await _roleMgr.AddClaimAsync(role, new Claim("IsAdmin", "True"));
        //        }

        //        user = new NephilaUser()
        //        {
        //            UserName = "nephila",
        //            Email = "jburns@nephilaadvisors.co.uk"
        //        };

        //        var userResult = await _userMgr.CreateAsync(user, "Sp1d3rs!");
        //        var roleResult = await _userMgr.AddToRoleAsync(user, "Admin");
        //        var claimResult = await _userMgr.AddClaimAsync(user, new Claim("SuperUser", "True"));

        //        if (!userResult.Succeeded || !roleResult.Succeeded || !claimResult.Succeeded)
        //        {
        //            throw new InvalidOperationException("Failed to build user and roles");
        //        }
        //    }
        //}
    }
}
