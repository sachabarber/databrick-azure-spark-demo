﻿using Hangfire.Server;
using Microsoft.Extensions.Configuration;
using Nephila.Databricks.WebApi.Services;
using Polly;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Nephila.Databricks.WebApi.Services
{
    public class DatabricksJobRunner : IDatabricksJobRunner
    {
        private readonly IConfigurationRoot _config;
        private readonly IDatabricksRunPollingSvc _databricksRunPollingSvc;
        private readonly IDatabricksWebApiClient _databricksWebApiClient;
        private readonly IDatabricksJobRepository _jobRepository;
        private readonly IDatabricksJobStatusHandler _jobStatusHandler;

        public DatabricksJobRunner(IConfigurationRoot config,
            IDatabricksRunPollingSvc databricksRunPollingSvc,
            IDatabricksWebApiClient databricksWebApiClient,
            IDatabricksJobRepository jobRepository,
            IDatabricksJobStatusHandler jobStatusHandler
            )
        {
            _config = config;
            _databricksRunPollingSvc = databricksRunPollingSvc;
            _databricksWebApiClient = databricksWebApiClient;
            _jobRepository = jobRepository;
            _jobStatusHandler = jobStatusHandler;
        }

        public async Task Run(int jobId, PerformContext context)
        {
            var job = await _jobRepository.GetAsync(jobId);
            
            job.JobParameters.RunId = await _databricksWebApiClient.StartRunAsync(job.JobParameters);
            await _databricksRunPollingSvc.StartPollingAsync(job, context.CancellationToken);
        }

       
    }
}
