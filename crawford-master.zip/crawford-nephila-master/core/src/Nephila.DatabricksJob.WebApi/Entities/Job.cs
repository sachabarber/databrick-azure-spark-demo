﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace Nephila.Databricks.WebApi.Entities
{
    public abstract class Job<T> where T : class
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        [Required]
        [StringLength(50)]
        public string JobType { get; set; }

        [Required]
        [StringLength(50)]
        public string Status { get; set; }

        public string ExceptionDetails { get; set; }

        [Required]
        public DateTime DateTimeAddedUtc { get; set; }

        [Required]
        public DateTime DateTimeLastUpdatedUtc { get; set; }

        private string _jobParametersJson;
        internal string _JobParameters
        {
            get
            {
                _jobParametersJson = (_jobParametersObject == null) ? _jobParametersJson : JsonConvert.SerializeObject(_jobParametersObject);
                return _jobParametersJson;
            }
            set
            {
                _jobParametersJson = value;
                _jobParametersObject = JsonConvert.DeserializeObject<T>(value);
            }
        }

        private T _jobParametersObject;
        [NotMapped]
        public T JobParameters
        {
            get { return _jobParametersObject; }
            set
            {
                _jobParametersObject = value;
            }
        }

    }
}
