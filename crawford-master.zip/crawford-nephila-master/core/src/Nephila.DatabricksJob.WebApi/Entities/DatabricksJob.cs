﻿using Nephila.Databricks.WebApi.Models;
using Nephila.Databricks.WebApi.Models.Messages;
using System;
using System.Collections.Generic;
using System.Text;

namespace Nephila.Databricks.WebApi.Entities
{
    public class DatabricksJob : Job<DatabricksRunRequest>
    {
        public string RequestedByUser { get; internal set; }
    }
}
