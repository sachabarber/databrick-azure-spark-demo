﻿using AutoMapper;
using Hangfire;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Nephila.Databricks.Job.Shared.Models;
using Nephila.Databricks.WebApi.Services;
using Nephila.Databricks.WebApi.Entities;
using Nephila.Databricks.WebApi.Models.Examples;
using Swashbuckle.AspNetCore.Examples;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Nephila.Databricks.WebApi.Controllers
{
    [Produces("application/json")]
    [Route("api/v1/clusters/databricks")]
    [Authorize]
    public class CrawfordClusterMgrApiController : Controller
    {
        private readonly IDatabricksWebApiClient _databricksWebApiClient;
        private readonly IMapper _mapper;

        public CrawfordClusterMgrApiController(IDatabricksWebApiClient databricksWebApiClient,
            IMapper mapper)
        {
            _databricksWebApiClient = databricksWebApiClient;
            _mapper = mapper;
        }


        [HttpGet]
        [Route("/api/v1/clusters/databricks/get/{id}", Name = "GetClusterStatus")]
        [SwaggerRequestExample(typeof(string), typeof(DatabricksClusterRequestExample))]
        public async Task<IActionResult> Get(string id)
        {
            var clusterStatus = await _databricksWebApiClient.GetClusterStatusAsync(id);
            if (clusterStatus != null)
            {
                var mappedResponse = _mapper.Map<DatabricksJobResponse>(clusterStatus);
                return Ok(mappedResponse);
            }
            else
            {
                return NotFound();
            }
        }

        [HttpPost]
        [Route("/api/v1/clusters/databricks/start/{id}", Name = "StartCluster")]
        [SwaggerRequestExample(typeof(string), typeof(DatabricksClusterRequestExample))]
        public async Task<IActionResult> Start(string id)
        {
            var clusterStatus = await _databricksWebApiClient.StartClusterAsync(id);
            if (clusterStatus != null)
            {
                var mappedResponse = _mapper.Map<DatabricksJobResponse>(clusterStatus);
                return Ok(mappedResponse);
            }
            else
            {
                return NotFound();
            }
        }       
    }
}
