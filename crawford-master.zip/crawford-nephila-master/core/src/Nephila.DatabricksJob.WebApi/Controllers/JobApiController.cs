﻿using AutoMapper;
using Hangfire;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Nephila.Databricks.Job.Shared.Models;
using Nephila.Databricks.WebApi.Services;
using Nephila.Databricks.WebApi.Entities;
using Nephila.Databricks.WebApi.Models.Examples;
using Swashbuckle.AspNetCore.Examples;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Nephila.Databricks.WebApi.Controllers
{
    [Produces("application/json")]
    [Route("api/v1/jobs/databricks")]
    //[Authorize]
    public class JobApiController : Controller
    {
        private readonly IDatabricksJobRepository _jobRepository;
        private readonly IDatabricksJobRunner _jobRunner;
        private readonly IMapper _mapper;

        public JobApiController(IDatabricksJobRepository jobRepository,
            IDatabricksJobRunner jobRunner,
            IMapper mapper)
        {
            _jobRepository = jobRepository;
            _jobRunner = jobRunner;
            _mapper = mapper;
        }


        [HttpGet]
        [Route("/api/v1/jobs/databricks/{id}", Name = "GetJobById")]
        public async Task<IActionResult> Get(int id)
        {
            var job = await _jobRepository.GetAsync(id);
            if (job != null)
            {
                var mappedResponse = _mapper.Map<DatabricksJobResponse>(job);
                return Ok(mappedResponse);
            }
            else
            {
                return NotFound();
            }
        }

        [HttpGet]
        [Route("/api/v1/jobs/databricks", Name = "GetJobs")]
        public async Task<IActionResult> Get()
        {
            var jobs = await _jobRepository.GetAllAsync();
            if (jobs != null)
            {
                var mappedResponse = jobs.Select(x => _mapper.Map<DatabricksJobResponse>(x));
                return Ok(mappedResponse);
            }
            else
            {
                return NotFound();
            }
        }

        [HttpPost]
        [Route("/api/v1/jobs/databricks")]
        [SwaggerRequestExample(typeof(PutDatabricksJobRequest), typeof(PutDatabricksJobRequestExample))]
        public async Task<IActionResult> Post([FromBody]PutDatabricksJobRequest value)
        {
            var mappedJobRequest = _mapper.Map<DatabricksJob>(value);
            var job = await _jobRepository.InsertAsync(mappedJobRequest);
            BackgroundJob.Enqueue(() => _jobRunner.Run(job.Id, null));
            var mappedResponse = _mapper.Map<DatabricksJobResponse>(job);
            return CreatedAtRoute("GetJobById", new { id = job.Id }, mappedResponse);
        }       
    }
}
