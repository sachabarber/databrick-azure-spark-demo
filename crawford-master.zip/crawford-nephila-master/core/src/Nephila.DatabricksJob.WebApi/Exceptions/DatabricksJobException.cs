﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Nephila.Databricks.WebApi.Exceptions
{
    public class DatabricksJobException : Exception
    {
        public DatabricksJobException()
        {
        }

        public DatabricksJobException(string message)
        : base(message)
    {
        }

        public DatabricksJobException(string message, Exception inner)
        : base(message, inner)
    {
        }
    }
}
