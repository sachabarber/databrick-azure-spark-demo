﻿**Getting Started**
-------------------

The project has some large files that are checked in using git lfs.

Install git lfs using your preferred package manager.
I like Chocolatey https://chocolatey.org/ then from the cmd line: 
	choco install git-lfs

I like to disable automatically checking out the large files and only do it on demand.
If you like the sound of this, run 
	git lfs install --skip-smudge

You are now set to clone the codebase:

Clone https://stash.nephila.com/projects/SPIK/repos/crawford/browse


To pull the large files from git lfs:

    git lfs pull


The majority of the work so far is in jupyter notebooks. To install and run pyspark+jupyter on windows I followed this blog post:
https://medium.com/@GalarnykMichael/install-spark-on-windows-pyspark-4498a5d8d66c


Then to run the notebooks, cd to the notebooks directory and run

    pyspark --master local[*]

**Event Loss Extractor**
------------------------
Running the eventloss extractor:

    cd core\src\Nephila.EventSetExtractor.Console
    dotnet run -f "D:\tmp" -t "calculator" -i 2173245

For help with the arguments just run without any to see the options:

    dotnet run

